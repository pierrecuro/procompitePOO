<?php
require 'htmlCabeza.php';  


if(isset($_POST['Agregar'])) {
		$mensajeError = '';
		$articulo = trim($_POST['articulo']); 
	 
		$codigoMargesi = $_POST['codigoMargesi'];
		$bienFiscalizado = $_POST['bienFiscalizado']; 

		if($articulo == '') $mensajeError = 'articulo';
		if($mensajeError == ''){ try {
		// print_r($_POST);
		$sql = $conectar->prepare('INSERT INTO articulos (codigoArticulo, articulo,  codigoMargesi, bienFiscalizado) VALUES (codigoArticulo,:articulo,:codigoMargesi,:bienFiscalizado)');

		$sql->execute(array(':articulo' => $articulo,':codigoMargesi' => $codigoMargesi,':bienFiscalizado' => $bienFiscalizado));
		echo "<center>fue grabado</center>";
		 
		} 	catch(PDOException $e) {
		echo "<center>error</center>";


		}} 
}


if(isset($_GET['eliminar'])) {
		$codigoArticulo= $_GET['eliminar'];
		$sqlDelete = $conectar->prepare("DELETE FROM articulos WHERE codigoArticulo = ?");
		$sqlDelete->execute([$codigoArticulo]);
		$sqlDelete = null;
}


if(isset($_GET['editar'])) {
		$codigoArticulo= $_GET['editar']; 
		$sqlSelect = $conectar->prepare("SELECT * FROM `articulos` WHERE `codigoArticulo`= ?");
		$sqlSelect->execute([$codigoArticulo]);
		$unRegistro = $sqlSelect->fetch(PDO::FETCH_LAZY);
		if(!$unRegistro) exit('no hay registros');
		/*similares muestras de registros echo $unRegistro[0];echo $unRegistro->producto; echo $unRegistro['producto'];*/
		$sqlSelect = null;
}

 
if(isset($_POST['Modificar'])) {
		$codigoArticulo= $_POST['codigoArticulo'];
		$articulo = trim($_POST['articulo']);  
		$codigoMargesi = $_POST['codigoMargesi'];
		$bienFiscalizado = $_POST['bienFiscalizado'];
		$sqlModificar = $conectar->prepare("UPDATE `articulos` SET `articulo` = '$articulo', `codigoMargesi` = '$codigoMargesi', `bienFiscalizado` = '$bienFiscalizado' WHERE `codigoArticulo` = $codigoArticulo");
		$sqlModificar->execute([$codigoArticulo]);
		$sqlModificar = null;
		header('Location: articulosCRUD.php?action=2');
}

 
 
$tablaMargesiTipo = $conectar->prepare("SELECT * FROM `margesi` WHERE `tipo`='TIPO'");
$tablaMargesiTipo->setFetchMode(PDO::FETCH_ASSOC);
$tablaMargesiTipo->execute(); 

$tablaMargesiActivo = $conectar->prepare("SELECT * FROM `margesi` WHERE `tipo`='ACTIVO' ORDER BY `codigoMargesi` DESC");
$tablaMargesiActivo->setFetchMode(PDO::FETCH_ASSOC);
$tablaMargesiActivo->execute(); 

 
?> 
<div class="container">
  <h4 class="mb-3">ARTICULOS</h4>

<form action="" method="post"  > 
<div class="row">
                      <div class="col-md-10 mb-3">
                      <label for="country">articulo</label>
                      <input type="text" class="form-control" name="articulo" placeholder="" 
                      value="<?php if(isset($_GET['editar'])) {  echo $unRegistro->articulo; }?>" required style="text-transform:uppercase;" onkeyup="javascript:this.value=this.value.toUpperCase();">
                      </div>
 
                        

                        <div class="col-md-5 mb-3">
                          <label for="country">codigo Margesi</label>
                          <select class="custom-select d-block w-100"  name="codigoMargesi"   required="">
								<?php while ($row = $tablaMargesiTipo->fetch()){?> 
								<option value="<?php echo $row['codigoMargesi'];?>" <?php  
								if(isset($_GET['editar'])) {
								if ($row['codigoMargesi']==$unRegistro['codigoMargesi']) {echo "selected"; }
								}?> > <?php echo $row['margesi']; ?>
								</option>
								<?php } ?>                            
                          </select>
                        </div> 
             
                        <div class="col-md-2 mb-2">	
                          <label for="country">bienFiscalizado</label>
                          <select class="custom-select d-block w-100"  name="bienFiscalizado"   required="">
								<?php while ($row = $tablaMargesiActivo->fetch()){?> 
								<option value="<?php echo $row['codigoMargesi'];?>" <?php  
								if(isset($_GET['editar'])) {
								if ($row['codigoMargesi']==$unRegistro['bienFiscalizado']) {echo "selected"; }
								}?> > <?php echo $row['margesi']; ?>
								</option>
								<?php } ?>                            
                          </select>
                        </div> 


<div class="col-md-3 mb-3">
<?php if(isset($_GET['editar'])) {?>
<input type="submit" name='Modificar' value="modicar" class="btn btn-primary btn-lg btn-block" /> 
<input type="hidden"  name="codigoArticulo"  value="<?php if(isset($_GET['editar'])) {  echo $unRegistro->codigoArticulo; }?>" > 
<?php  } else {  ?>
<input type="submit" name='Agregar' value="Agregar" class="btn btn-primary btn-lg btn-block" />
<?php  }?>
</div>
<div class="col-md-2 mb-2">
<a href="articulosCRUD.php" class="btn btn-primary btn-lg btn-block" style="background: #fff !important;color: #000 !important;" />Nuevo</a>
</div>

  </div> 
</form>

<!---INICIO LISTADO---->
<h2>PRODUCTOS</h2>
          <div class="table-responsive">
            <table class="table table-striped table-sm">
              <thead>
                <tr  align="">
                  <th>N°</th>
                  <th>codigoArticulo</th>
                  <th>articulo</th> 
                  <th>codigoMargesi</th> 
                  <th>bienFiscalizado</th>  
                  <th> </th>  
                </tr>
              </thead>
              <tbody>                 
					<?php
					$i=1;
					$sqlPDO = $conectar->prepare("SELECT a.*,g.* FROM  articulos a,margesi g WHERE   g.codigoMargesi=a.codigoMargesi ORDER BY a.codigoArticulo DESC");
					$sqlPDO->execute(array(':codigoArticulo' => 0));
					$lista = $sqlPDO->fetchAll(PDO::FETCH_ASSOC);
					foreach($lista as $obj){ 
					echo  "<tr><td>".$i."</td><td>".$obj['codigoArticulo']."</td><td>".$obj['articulo']."</td> <td>".$obj['margesi']."</td> <td>".$obj['bienFiscalizado']."</td>      <td> <a href=?editar=".$obj['codigoArticulo'].">Editar</a></td>  </tr>";  $i++;
					}?>
              </tbody>
            </table>
          </div> 
<!---FIN LISTADO---->


</div>        
 
<?php
  require 'htmlPie.php'; 
?>