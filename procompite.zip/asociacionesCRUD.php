<?php
require 'htmlCabeza.php';  

if(isset($_POST['Agregar'])) {
		$mensajeError = '';
		$codigoUnificado = trim($_POST['codigoUnificado']);
		$convocatoria = trim($_POST['convocatoria']);
		$fechaResolucion = trim($_POST['fechaResolucion']);
		$resolucion = trim($_POST['resolucion']);
		$categoria = trim($_POST['categoria']);
		$eslabon = trim($_POST['eslabon']);
		$cadenaProductiva = trim($_POST['cadenaProductiva']);
		$sector = trim($_POST['sector']);
		$codigoSIProcompite = trim($_POST['codigoSIProcompite']);
		$nroPartidaSUNARP = trim($_POST['nroPartidaSUNARP']);
		$nombreAEO = trim($_POST['nombreAEO']);
		$nombreProyecto = trim($_POST['nombreProyecto']);
		$aporteAEOEfectivo = trim($_POST['aporteAEOEfectivo']);
		$aporteAEOValorizado = trim($_POST['aporteAEOValorizado']);
		$aporteDelMunicipio = trim($_POST['aporteDelMunicipio']);
		$tipoAsociacion = trim($_POST['tipoAsociacion']);
		$observaciones = trim($_POST['observaciones']);
		$cierreActa = 'NO'; 

			 


		if($mensajeError == ''){ try {
		// print_r($_POST);
		$sqlInsert = $conectar->prepare('INSERT INTO asociaciones (codigoUnificado, convocatoria, resolucion, categoria, eslabon, cadenaProductiva, sector, codigoSIProcompite, nroPartidaSUNARP, nombreAEO, aporteAEOEfectivo, nombreProyecto, aporteAEOValorizado, aporteDelMunicipio, tipoAsociacion, observaciones, cierreActa, fechaResolucion) VALUES (:codigoUnificado,:convocatoria,:resolucion,:categoria,:eslabon,:cadenaProductiva,:sector,:codigoSIProcompite,:nroPartidaSUNARP,:nombreAEO,:aporteAEOEfectivo,:nombreProyecto,:aporteAEOValorizado,:aporteDelMunicipio,:tipoAsociacion,:observaciones,:cierreActa,:fechaResolucion)');
		$sqlInsert->execute(array(':codigoUnificado' => $codigoUnificado,':convocatoria' => $convocatoria,':resolucion' => $resolucion,':categoria' => $categoria,':eslabon' => $eslabon,':cadenaProductiva' => $cadenaProductiva,':sector' => $sector,':codigoSIProcompite' => $codigoSIProcompite,':nroPartidaSUNARP' => $nroPartidaSUNARP,':nombreAEO' => $nombreAEO,':aporteAEOEfectivo' => $aporteAEOEfectivo,':nombreProyecto' => $nombreProyecto,':aporteAEOValorizado' => $aporteAEOValorizado,':aporteDelMunicipio' => $aporteDelMunicipio,':tipoAsociacion' => $tipoAsociacion,':observaciones' => $observaciones,':cierreActa' => $cierreActa,':fechaResolucion' => $fechaResolucion));
		header('Location: asociacionesCRUD.php?action=1');
		exit;
		} catch(PDOException $e) {
		echo $e->getMessage();
		}} 
}

if(isset($_GET['eliminar'])) {
		$codigoAsociacion= $_GET['eliminar'];
		$codigoUnificado= trim($_GET['codigoUnificado']);

		$sqlDelete = $conectar->prepare("DELETE FROM asociaciones WHERE codigoAsociacion = ?");
		$sqlDelete->execute([$codigoAsociacion]);
		$sqlDelete = null;

		$sql = $conectar->prepare("DELETE FROM socios WHERE codigoUnificado = ?");
		$sql->execute([$codigoUnificado]);
		$sql = null;

}

if(isset($_GET['editar'])) {
		$codigoAsociacion= $_GET['editar']; 
		$sqlSelect = $conectar->prepare("SELECT * FROM `asociaciones` WHERE `codigoAsociacion`= ?");
		$sqlSelect->execute([$codigoAsociacion]);
		$unRegistro = $sqlSelect->fetch(PDO::FETCH_LAZY);
		if(!$unRegistro) exit('no hay registros');
		/*similares muestras de registros echo $unRegistro[0];echo $unRegistro->producto; echo $unRegistro['producto'];*/
		$sqlSelect = null;
}

if(isset($_POST['Modificar'])) {
		$codigoUnificado = trim($_POST['codigoUnificado']);
		$convocatoria = trim($_POST['convocatoria']);
		$fechaResolucion = trim($_POST['fechaResolucion']);
		$resolucion = trim($_POST['resolucion']);
		$categoria = trim($_POST['categoria']);
		$eslabon = trim($_POST['eslabon']);
		$cadenaProductiva = trim($_POST['cadenaProductiva']);
		$sector = trim($_POST['sector']);
		$codigoSIProcompite = trim($_POST['codigoSIProcompite']);
		$nroPartidaSUNARP = trim($_POST['nroPartidaSUNARP']);
		$nombreAEO = trim($_POST['nombreAEO']);
		$codigoUnificadoAnterior = trim($_POST['codigoUnificadoAnterior']);
		$nombreProyecto = trim($_POST['nombreProyecto']);
		$aporteAEOEfectivo = trim($_POST['aporteAEOEfectivo']);
		$aporteAEOValorizado = trim($_POST['aporteAEOValorizado']);
		$aporteDelMunicipio = trim($_POST['aporteDelMunicipio']);
		$tipoAsociacion = trim($_POST['tipoAsociacion']);
		$observaciones = trim($_POST['observaciones']);
		$cierreActa = trim($_POST['cierreActa']); 
		$codigoAsociacion= trim($_POST['codigoAsociacion']);

		$sqlModificar = $conectar->prepare("UPDATE `asociaciones` SET `codigoUnificado` = '$codigoUnificado', `nombreProyecto` = '$nombreProyecto', `convocatoria` = '$convocatoria', `fechaResolucion` = '$fechaResolucion', `resolucion` = '$resolucion', `categoria` = '$categoria', `eslabon` = '$eslabon', `cadenaProductiva` = '$cadenaProductiva', `sector` = '$sector', `codigoSIProcompite` = '$codigoSIProcompite', `nroPartidaSUNARP` = '$nroPartidaSUNARP', `nombreAEO` = '$nombreAEO', `aporteAEOEfectivo` = '$aporteAEOEfectivo', `aporteDelMunicipio` = '$aporteDelMunicipio', `aporteAEOValorizado` = '$aporteAEOValorizado', `tipoAsociacion` = '$tipoAsociacion', `observaciones` = '$observaciones'  WHERE `codigoAsociacion` = $codigoAsociacion");
		$sqlModificar->execute([$codigoAsociacion]);
		$sqlModificar = null;


		$sql = $conectar->prepare("UPDATE `socios` SET `codigoUnificado` = '$codigoUnificado'  WHERE `codigoUnificado` = '$codigoUnificadoAnterior'");
		$sql->execute([$codigoUnificadoAnterior]);
		$sql = null;

 


		header('Location: asociacionesCRUD.php?action=2');
}

?> 
<div class="container">
  <h4 class="mb-3">asociaciones</h4>

<form action="" method="post"  > 
<div class="row">
	
		<div class="col-md-2 mb-3">
		<label for="country">codigoUnificado</label>
		<input type="text" class="form-control" name="codigoUnificado" placeholder="" 
		value="<?php if(isset($_GET['editar'])) {  echo $unRegistro->codigoUnificado; }?>" required style="text-transform:uppercase;" onkeyup="javascript:this.value=this.value.toUpperCase();">
		</div>

 
		<input type="hidden" name="codigoUnificadoAnterior" value="<?php if(isset($_GET['editar'])) {  echo $unRegistro->codigoUnificado; }?>" required  >
		 
		
	
		<div class="col-md-10 mb-3">
		<label for="country">nombreProyecto</label>
		<input type="text" class="form-control" name="nombreProyecto" placeholder="" 
		value="<?php if(isset($_GET['editar'])) {  echo $unRegistro->nombreProyecto; }?>" required style="text-transform:uppercase;" onkeyup="javascript:this.value=this.value.toUpperCase();">
		</div>

   

	
		<div class="col-md-2 mb-2">
		<label for="country">convocatoria #</label>
		<input type="text" class="form-control" name="convocatoria" placeholder="" 
		value="<?php if(isset($_GET['editar'])) {  echo $unRegistro->convocatoria; }?>" required style="text-transform:uppercase;" onkeyup="javascript:this.value=this.value.toUpperCase();">
		</div>
	
		<div class="col-md-2 mb-2">
		<label for="country">cadenaProductiva  </label>
		<input type="text" class="form-control" name="cadenaProductiva" placeholder="" 
		value="<?php if(isset($_GET['editar'])) {  echo $unRegistro->cadenaProductiva; }?>" required style="text-transform:uppercase;" onkeyup="javascript:this.value=this.value.toUpperCase();">
		</div>
	
		<div class="col-md-2 mb-2">
		<label for="country">eslabon </label>
		<input type="text" class="form-control" name="eslabon" placeholder="" 
		value="<?php if(isset($_GET['editar'])) {  echo $unRegistro->eslabon; }?>" required style="text-transform:uppercase;" onkeyup="javascript:this.value=this.value.toUpperCase();">
		</div>

 

		<div class="col-md-3 mb-3">
		<label for="country">resolucion</label>
		<input type="text" class="form-control" name="resolucion" placeholder="" 
		value="<?php if(isset($_GET['editar'])) {  echo $unRegistro->resolucion; }?>" required style="text-transform:uppercase;" onkeyup="javascript:this.value=this.value.toUpperCase();">
		</div>
	
		<div class="col-md-2 mb-3">
		<label for="country">fechaResolucion</label>
		<input type="text" class="form-control" name="fechaResolucion" placeholder="" 
		value="<?php if(isset($_GET['editar'])) {  echo $unRegistro->fechaResolucion; }?>" required style="text-transform:uppercase;" onkeyup="javascript:this.value=this.value.toUpperCase();">
		</div>
	
		<div class="col-md-2 mb-3">
		<label for="country">categoria</label>
		<input type="text" class="form-control" name="categoria" placeholder="" 
		value="<?php if(isset($_GET['editar'])) {  echo $unRegistro->categoria; }?>" required style="text-transform:uppercase;" onkeyup="javascript:this.value=this.value.toUpperCase();">
		</div>
	
		<div class="col-md-2 mb-3">
		<label for="country"><b>sector</b></label>
		<input type="text" class="form-control" name="sector" placeholder="" 
		value="<?php if(isset($_GET['editar'])) {  echo $unRegistro->sector; }?>" required style="text-transform:uppercase;" onkeyup="javascript:this.value=this.value.toUpperCase();">
		</div>

	
		<div class="col-md-5 mb-3">
		<label for="country">nombreAEO</label>
		<input type="text" class="form-control" name="nombreAEO" placeholder="" 
		value="<?php if(isset($_GET['editar'])) {  echo $unRegistro->nombreAEO; }?>" required style="text-transform:uppercase;" onkeyup="javascript:this.value=this.value.toUpperCase();">
		</div>




		
		<div class="col-md-2 mb-3">
		<label for="country">aporteAEOValorizado</label>
		<input type="text" class="form-control" name="aporteAEOValorizado" placeholder="" 
		value="<?php if(isset($_GET['editar'])) {  echo $unRegistro->aporteAEOValorizado; }?>" required style="text-transform:uppercase;" onkeyup="javascript:this.value=this.value.toUpperCase();">
		</div>


		
		<div class="col-md-2 mb-3">
		<label for="country">aporteDelMunicipio</label>
		<input type="text" class="form-control" name="aporteDelMunicipio" placeholder="" 
		value="<?php if(isset($_GET['editar'])) {  echo $unRegistro->aporteDelMunicipio; }?>" required style="text-transform:uppercase;" onkeyup="javascript:this.value=this.value.toUpperCase();">
		</div>


		
		<div class="col-md-2 mb-3">
		<label for="country">tipoAsociacion</label>
		<input type="text" class="form-control" name="tipoAsociacion" placeholder="" 
		value="<?php if(isset($_GET['editar'])) {  echo $unRegistro->tipoAsociacion; }?>" required style="text-transform:uppercase;" onkeyup="javascript:this.value=this.value.toUpperCase();">
		</div>

</div>


<div class="row">

		
		<div class="col-md-12 mb-3">
		<h4 class="mb-3">si ubiera información ingresar</h4>
		</div>

		<div class="col-md-2 mb-3">
		<label for="country">codigoSIProcompite</label>
		<input type="text" class="form-control" name="codigoSIProcompite" placeholder="" 
		value="<?php if(isset($_GET['editar'])) {  echo $unRegistro->codigoSIProcompite; }?>"  style="text-transform:uppercase;" onkeyup="javascript:this.value=this.value.toUpperCase();">
		</div>
	
		<div class="col-md-2 mb-3">
		<label for="country">nroPartidaSUNARP</label>
		<input type="text" class="form-control" name="nroPartidaSUNARP" placeholder="" 
		value="<?php if(isset($_GET['editar'])) {  echo $unRegistro->nroPartidaSUNARP; }?>"  style="text-transform:uppercase;" onkeyup="javascript:this.value=this.value.toUpperCase();">
		</div>

		<div class="col-md-2 mb-3">
		<label for="country">aporteAEOEfectivo</label>
		<input type="text" class="form-control" name="aporteAEOEfectivo" placeholder="" 
		value="<?php if(isset($_GET['editar'])) {  echo $unRegistro->aporteAEOEfectivo; }?>"   style="text-transform:uppercase;" onkeyup="javascript:this.value=this.value.toUpperCase();">
		</div>


		
		<div class="col-md-5 mb-3">
		<label for="country">observaciones</label>
		<input type="text" class="form-control" name="observaciones" placeholder="" 
		value="<?php if(isset($_GET['editar'])) {  echo $unRegistro->observaciones; }?>"  style="text-transform:uppercase;" onkeyup="javascript:this.value=this.value.toUpperCase();">
		</div>
 

		<div class="col-md-3 mb-3">
		<?php if(isset($_GET['editar'])) {?>
		<input type="submit" name='Modificar' value="modicar" class="btn btn-primary btn-lg btn-block" /> 
		<input type="hidden"  name="codigoAsociacion"  value="<?php if(isset($_GET['editar'])) {  echo $unRegistro->codigoAsociacion; }?>" > 
		<?php  } else {  ?>
		<input type="submit" name='Agregar' value="Agregar" class="btn btn-primary btn-lg btn-block" />
		<?php  }?>
		</div>
		<div class="col-md-2 mb-2">
		<a href="asociacionesCRUD.php" class="btn btn-primary btn-lg btn-block" style="background: #fff !important;color: #000 !important;" />Nuevo</a>
		</div>



  </div> 
</form>

<!---INICIO LISTADO---->
	<h2>LISTA DE ASOCIACIONES</h2>
          <div class="table-responsive">
            <table class="table table-striped table-sm">
              <thead>
                <tr  align="">
                  <th>N°</th>
                  <th>Convocatoria</th>
                  <th>codigo Asociacion</th>
                  <th>Nombre de Asociaciones</th> 
                  <th>cadena Productiva</th> 
                  <th>fecha Resolución</th> 
                  <th> </th>  
                </tr>
              </thead>
              <tbody>                 
					<?php	
					$i=1;
					$sqlPDO = $conectar->prepare("SELECT * FROM `asociaciones` ORDER BY `asociaciones`.`codigoAsociacion` DESC");
					$sqlPDO->execute(array(':codigoAsociacion' => 0));
					$lista = $sqlPDO->fetchAll(PDO::FETCH_ASSOC);
					foreach($lista as $obj){ 
					echo  "<tr><td>".$i."</td><td>".$obj['convocatoria']."</td><td>".$obj['codigoUnificado']."</td><td>".$obj['nombreProyecto']."</td> <td>".$obj['cadenaProductiva']."</td> <td>".$obj['fechaResolucion']."</td>  <td>";
					if($obj['cierreActa']=='NO'){
					echo "<a href=?editar=".$obj['codigoAsociacion']."&codigoUnificado=".$obj['codigoUnificado'].">Editar</a> <br>";
					echo "<a href=?eliminar=".$obj['codigoAsociacion']."&codigoUnificado=".$obj['codigoUnificado'].">Eliminar</a>";

					}

					echo "</td>  </tr>";  $i++;
					}?>
              </tbody>
            </table>
          </div> 
<!---FIN LISTADO---->


</div>        
 
<?php
  require 'htmlPie.php'; 
?>