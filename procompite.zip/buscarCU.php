<?php
require 'htmlCabeza.php';  
// print_r($_POST);
//print_r($_POST);

if(isset($_POST['Buscar'])) {
        $mensajeError = ''; 
        $codigoUnificado = $_POST['codigoUnificado']; 
 

         $sqlSelect = $conectar->prepare("SELECT  s.nombreAEO,a.articulo,s.cadenaProductiva,s.sector,s.nombreProyecto,e.* FROM articulos a,entregas e,asociaciones s WHERE a.codigoArticulo=e.codigoArticulo and s.codigoUnificado=e.codigoUnificado and e.codigoUnificado= ?"); 
        $sqlSelect->execute([$codigoUnificado]);
        $unRegistro = $sqlSelect->fetch(PDO::FETCH_LAZY);

            if(!$unRegistro) {
            echo "<center><h1>no hay registros con este codigo unificado: ".$codigoUnificado."</h1></center>";
            exit('<center> .... </center>');  
            /*similares muestras de registros echo $unRegistro[0];echo $unRegistro->producto; echo $unRegistro['producto'];*/
            $sqlSelect = null;}
}


?> 




    <script type="text/javascript">
    $(document).ready(function(){
                $(document).on('keydown', '.sector', function() {
                    var codigoAsociacion = this.id;
                    var splitid = codigoAsociacion.split('_');
                    var index = splitid[1];
                            $( '#'+codigoAsociacion ).autocomplete({
                                source: function( request, response ) {
                                    $.ajax({
                                        url: "buscarCUAjax.php",
                                        type: 'post',
                                        dataType: "json",
                                        data: {
                                            search: request.term,request:1
                                        },
                                        success: function( data ) {
                                            response( data );
                                        }
                                    });
                                },
                                select: function (event, ui) {
                                    $(this).val(ui.item.label); // display the selected text
                                    var varcodigoAsociacion = ui.item.value; // selected id to input
                                    // AJAX
                                    $.ajax({
                                        url: 'buscarCUAjax.php',
                                        type: 'post',
                                        data: {varcodigoAsociacion:varcodigoAsociacion,request:2},
                                        dataType: 'json',
                                        success:function(response){
                                            var len = response.length;
                                            if(len > 0){
                                                var codigoAsociacion = response[0]['codigoAsociacion'];
                                                var nombreProyecto = response[0]['nombreProyecto'];
                                                var codigoUnificado = response[0]['codigoUnificado'];
                                                var cadenaProductiva = response[0]['cadenaProductiva'];
                                                var sector = response[0]['sector'];
                                                var nombreAEO = response[0]['nombreAEO']; 
                                                document.getElementById('nombreProyecto_'+index).value = nombreProyecto;
                                                document.getElementById('codigoAsociacion_'+index).value = codigoAsociacion;
                                                document.getElementById('codigoUnificado_'+index).value = codigoUnificado;
                                                document.getElementById('cadenaProductiva_'+index).value = cadenaProductiva;
                                                document.getElementById('sector_'+index).value = sector; 
                                                document.getElementById('nombreAEO_'+index).value = nombreAEO;
                                            }
                                        }
                                    });
                                    return false;
                                }
                            });
                });
    });
    </script>
 



<div class="container">
  <h4 class="mb-3">BUSCAR PRODUCTOS QUE ENTREGARON A ASOCIACION</h4>

<form action="" method="POST"  > 
    <div class="row">
            <div class="col-md-10 mb-3">
                    <label for="country">Buscar plan de Negocio </label><br>
                    <input type='text'    autofocus    style="width: 450px !important; "   class='sector' id='sector_1' placeholder='buscar Sector' value="<?php if(isset($_POST['Buscar'])) {  echo $unRegistro->sector; }?>">
                    <input type='hidden'  id='codigoAsociacion_1' disabled >
                    <input type='text'  id='cadenaProductiva_1' disabled  value="<?php if(isset($_POST['Buscar'])) {  echo $unRegistro->cadenaProductiva; }?>"> 
                    - 
                    <input type='text' name='codigoUnificado' id='codigoUnificado_1'   value="<?php if(isset($_POST['Buscar'])) {  echo $unRegistro->codigoUnificado; }?>">
                    <br> nombreProyecto: <input type='text'   id='nombreProyecto_1' disabled style="width: 1100px !important; font-size: 9px;"  value="<?php if(isset($_POST['Buscar'])) {  echo $unRegistro->nombreProyecto; }?>"> 
                    <br>nombreAEO: <input type='text'   id='nombreAEO_1' disabled style="width: 900px !important; font-size: 9px;"  value="<?php if(isset($_POST['Buscar'])) {  echo $unRegistro->nombreAEO; }?>"> 
            </div> 
            <div class="col-md-3 mb-3">
                    <input type="submit" name='Buscar' value="buscar" class="btn btn-primary btn-lg btn-block" />
            </div> 
    </div> 
</form>

<?php 
if(isset($_POST['Buscar'])) {   
?>

<!---INICIO LISTADO---->
<h2>LISTA DE ENTREGAS</h2>
          <div class="table-responsive">
            <table class="table table-striped table-sm">
              <thead>
                <tr  align="">
                  <th>N°</th>
                  <th>sector</th>
                  <th>codigo Unificado</th>
                  <th>articulo</th>
                  <th>unidad Medida</th> 
                  <th>marca</th>  
                  <th> </th>  
                  <th>cantidad Referencial</th>  
                </tr>
              </thead>
              <tbody>                 
                    <?php 
                     $fechaHoy = date("Y-m-d"); 
                    $i=1;
                    $sqlPDO = $conectar->prepare("SELECT s.nombreAEO,e.cantidadReferencial,e.fechaCreacion,e.codigoEntrega,s.codigoUnificado,s.cadenaProductiva,s.sector,a.articulo,m.unidadMedida,r.marca,s.cierreActa FROM entregas e, asociaciones s, medidas m,articulos a, marcas r WHERE a.codigoArticulo=e.codigoArticulo and m.codigoMedida=e.codigoMedida and r.codigoMarca=e.codigoMarca and s.codigoUnificado=e.codigoUnificado and s.codigoUnificado='$codigoUnificado' ORDER BY e.codigoEntrega DESC");

                    $sqlPDO->execute(array(':codigoArticulo' => 0));
                    $lista = $sqlPDO->fetchAll(PDO::FETCH_ASSOC);
                    foreach($lista as $obj){ 
                    echo  "<tr><td>".$i."</td><td>".$obj['cadenaProductiva']." <br><b> ".$obj['sector']."</b></td><td><b>".$obj['codigoUnificado']."</b></td><td>".$obj['articulo']."</td> <td>".$obj['unidadMedida']."</td> <td>".$obj['marca']."</td>      <td>";
                    echo "</td> <td>".$obj['cantidadReferencial']."</td> </tr>";  $i++;
                    }?>
              </tbody>
            </table>
          </div> 
<!---FIN LISTADO---->
<?php
}
 

?>

</div>        
 
<?php
  require 'htmlPie.php'; 

?>