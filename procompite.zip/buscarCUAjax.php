<?php
include "config.php";

$request = $_POST['request'];    

if($request == 1){
    $search = $_POST['search'];
    //SELECT CONCAT(ApeEmpleado, ',' ,NomEmpleado) as Nombre

    $gsent = $conectar->prepare("SELECT * FROM asociaciones where nombreProyecto like '%$search%'");
    $gsent->execute(); 
    while($rows=$gsent->FETCH(PDO::FETCH_ASSOC)){
        $response[] = array("value"=>$rows['codigoAsociacion'],"label"=>$rows['nombreProyecto']);
    }
    echo json_encode($response);
    exit;
}
  


if($request == 2){  
    $varcodigoAsociacion = $_POST['varcodigoAsociacion'];
    $gsent = $conectar->prepare("SELECT * FROM asociaciones where codigoAsociacion ='$varcodigoAsociacion'");
    $gsent->execute(); 
    $users_arr = array();   
    while($row=$gsent->FETCH(PDO::FETCH_ASSOC)){
            $varcodigoAsociacion = $row['codigoAsociacion']; 
            $nombreProyecto = $row['nombreProyecto']; 
            $codigoUnificado = $row['codigoUnificado'];
            $sector = $row['sector'];
            $nombreAEO = $row['nombreAEO'];
            
            
            //$sector = $row['sector']." ".$row['cadenaProductiva'];

            $cadenaProductiva = $row['cadenaProductiva'];
            $users_arr[] = array("codigoAsociacion" => $varcodigoAsociacion, "nombreProyecto" => $nombreProyecto, "codigoUnificado" => $codigoUnificado, "sector" => $sector, "cadenaProductiva" => $cadenaProductiva, "nombreAEO" => $nombreAEO);
    } 
    echo json_encode($users_arr);
    exit;
}
  
?>