<?php
require 'htmlCabeza.php'; 
 
//00162181
     $totalEntregas='0';
 
 
if(isset($_GET['buscarDNI']) and $_GET['buscarDNI']!='' ) {
      $dni = trim($_GET['buscarDNI']);
 

    $sqlDNI=$conectar->prepare("SELECT distinct d.codigoUnificado ,d.dni,p.nombres,p.aPaterno,p.aMaterno  FROM datos d,personas p  WHERE d.dni='$dni' and d.dni=p.dni");
    $sqlDNI->execute();
    $registro = $sqlDNI->fetch(PDO::FETCH_OBJ); 
    //echo  "DDD".$registro;

    if(isset($registro->codigoUnificado)) {

          $codigoUnificado=$registro->codigoUnificado;
          $dni=$registro->dni;
          $nombreCompleto=$registro->nombres." ".$registro->aPaterno." ".$registro->aMaterno;


          $sqlSeleccion=$conectar->prepare("SELECT * FROM `asociaciones` WHERE codigoUnificado='$codigoUnificado'");
          $sqlSeleccion->execute();
          $registros = $sqlSeleccion->fetch(PDO::FETCH_OBJ);


          $sqlEntregas=$conectar->prepare("SELECT count(*) as totalEntregas FROM `entregas` WHERE codigoUnificado='$codigoUnificado'");
          $sqlEntregas->execute();
          $registro = $sqlEntregas->fetch(PDO::FETCH_OBJ);
          $totalEntregas=$registro->totalEntregas;


          $sqlTablaEntrega=$conectar->prepare("SELECT e.cantidadReferencial,e.codigoEntrega,s.codigoUnificado,s.cadenaProductiva,s.sector,a.articulo,m.unidadMedida,r.marca FROM entregas e, asociaciones s, medidas m,articulos a, marcas r WHERE  s.codigoUnificado='$codigoUnificado' and a.codigoArticulo=e.codigoArticulo and m.codigoMedida=e.codigoMedida and r.codigoMarca=e.codigoMarca and s.codigoUnificado=e.codigoUnificado ORDER BY e.codigoEntrega ASC");
          $sqlTablaEntrega->execute(); 
    } else { echo "<center><h1 style='color:red;'>no hay producto asignado al dni :".$_GET['buscarDNI']."</h1></center>"; 
     $totalEntregas='0';
  }
 
 
}



?>




<div class="container">

  

<div class="row">
      <div class="col-md-9 order-md-9">  
        <h4 class="mb-4">BUSQUEDA DE PRODUCTOS ASIGNADOS A BENEFICIARIOS POR DNI</h4>
        <form   method="Get" class="needs-validation" novalidate> 
              <div class="col-md-6 mb-6">
                    <div class="input-group">
                      <div class="input-group-prepend"><span class="input-group-text"> BUSQUEDA DNI</span></div>
                      <input class="form-control" type="number" id="CU" name='buscarDNI' placeholder="buscar DNI" required min="1" pattern="[0-9]+" onpaste="return true;" onDrop="return false;" autocomplete=off>
                    </div>  
              </div>
            
                <div class="col-md-3 mb-3">
                    <div class="input-group"> 
                    <input type="submit" name='buscar' value="Buscar" class="btn btn-primary btn-lg btn-block" />  
                    </div>
              </div>
      </form>
      </div>
</div>

<?php
//inicio
if(isset($_GET['buscarDNI'])  ) {

if($totalEntregas>0) {
?>
 <b>nombre Proyecto:</b> 
<?php 
echo "<br>".$registros->nombreProyecto."<br>";
echo "<b>nombre Corto : ".$registros->sector." ".$registros->cadenaProductiva."</b><br>"; 
echo "<b>Convocatoria : #</b>".$registros->convocatoria."<br>";
echo "<b>fecha Resolución : </b>".$registros->fechaResolucion."<br>";
echo "<b>resolucion : </b>".$registros->resolucion."<br>";
echo "<b>codigo Unificado :</b>".$codigoUnificado;
?> 
 
      <div class="panel-body"> 
        <h4 class="mb-3" style="color: blue;">PRODUCTOS ENTREGADOS : <?php  echo "<b>".$nombreCompleto."</b> con  DNI:<b>".$dni."</b>";   ?>  </h4>
          <form   method="POST" class="needs-validation" >
                  <table border="1" class="table table-bordered table-striped">
                      <tr>
                        <th>N°</th> 
                        <th>Articulos</th>
                        <th >Unidad Medida</th>
                        <th>Cantidad</th>  
                        <th>Marca</th>  
                      </tr>

                    <?php
                    $c=1;$dni=0;
                    while($row=$sqlTablaEntrega->FETCH(PDO::FETCH_ASSOC)){
                    echo '
                    <tr>
                    <td>'.$c.'</td> 
                    <td>'.$row["articulo"].'</td>
                    <td>'.$row["unidadMedida"].'</td> 
                    <td>'.'<input type=hidden name=arrayCodigoEntregas[] size=1 value='.$row['codigoEntrega'].'>
                    '.$row['cantidadReferencial'].''.'</td>
                    <td>'.$row["marca"].'</td> 
                    </tr>';
                    $c++;} 
                    ?>
                  </table>
                </div>  
          </form> 
          <?php } else { /*echo "<h2 style='color:red;'>Falta Asignar las <a href='entregasCRUD.php'>ENTREGAS</a></h2> "; */}  
} 
?> 
      
          
</div> 
</div>

 

 
<?php
  require 'htmlPie.php'; 
?>