<?php
require 'htmlCabeza.php'; 
 
//00162181
     $totalEntregas='0';
 
 
if(isset($_GET['buscarDNI']) and $_GET['buscarDNI']!='' ) {
      $dni = trim($_GET['buscarDNI']);
 

    $sqlDNI=$conectar->prepare("SELECT *  FROM  personas   WHERE dni='$dni'");
    $sqlDNI->execute();
    $registro = $sqlDNI->fetch(PDO::FETCH_OBJ); 
 

    if(isset($registro->dni)) { 
        //$codigoUnificado=$registro->codigoUnificado;
        $dni=$registro->dni;
        $nombreCompleto=$registro->nombres." ".$registro->aPaterno." ".$registro->aMaterno;
        echo "<center><h1 style='color:blue;'> DNI :".$nombreCompleto." <br>Fecha Nacimiento:".$registro->fechaNacimiento."<br><a href='personasCRUD.php?editar=".$registro->codigoPersonal."'>Editar</a> <br><a href='buscarDNI.php?buscarDNI=".$registro->dni."'>ver si tiene Productos Asignados</a>  </h1></center>";  
 

    } else { echo "<center><h1 style='color:red;'>no existe en la base de datos este DNI :".$_GET['buscarDNI']."</h1></center>"; 
     $totalEntregas='0';
  }
 
 
}



?>




<div class="container">

  

<div class="row">
      <div class="col-md-99 order-md-9">  
        <h4 class="mb-3">BUSQUEDA PERSONAL BENEFICIARIAS SI EXISTEN EN LA BASE DE DATOS</h4>
        <form   method="Get" class="needs-validation" novalidate> 
              <div class="col-md-6 mb-6">
                    <div class="input-group">
                      <div class="input-group-prepend"><span class="input-group-text"> BUSQUEDA DNI</span></div>
                      <input class="form-control" type="number" id="CU" name='buscarDNI' placeholder="buscar DNI" required min="1" pattern="[0-9]+" onpaste="return true;" onDrop="return false;" autocomplete=off>
                    </div>  
              </div>
            
                <div class="col-md-3 mb-3">
                    <div class="input-group"> 
                    <input type="submit" name='buscar' value="Buscar" class="btn btn-primary btn-lg btn-block" />  
                    </div>
              </div>
      </form>
      </div>


</div>

  
          
</div> 
</div>

 

 
<?php
  require 'htmlPie.php'; 
?>