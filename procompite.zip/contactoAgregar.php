<?php
require 'htmlCabeza.php';  

if(isset($_POST['Agregar']) and isset($_POST['asunto'])  ) {
    $mensajeError = '';
      //POST FROM codigoContacto
 //print_r($_POST);

      $nombres = $_POST['nombres'];
      $apellidos = $_POST['apellidos'];
      $email = $_POST['email'];
      $fechaArribo = $_POST['fechaArribo'];
      $pais = $_POST['pais'];
      $asunto = $_POST['asunto'];
      $mensaje = $_POST['mensaje'];
      $fechaSistema=$_POST['fechaSistema']; 
      $url =$_POST['url'];
      $preferencia =$_POST['preferencia'];  
 
    if($mensajeError == ''){ try {
 
      $sql = $conectar->prepare('INSERT INTO contactos (nombres,apellidos,email,fechaArribo,pais,asunto,mensaje,fechaSistema,url,preferencia) VALUES(:nombres,:apellidos,:email,:fechaArribo,:pais,:asunto,:mensaje,:fechaSistema,:url,:preferencia)');
        $sql->execute(array(':nombres' => $nombres,':apellidos' => $apellidos,':email' => $email,':fechaArribo' => $fechaArribo,':pais' => $pais,':asunto' => $asunto,':mensaje' => $mensaje,':fechaSistema' => $fechaSistema,':url' => $url,':preferencia' => $preferencia));
  header('Location: contactoAgregar.php?action=1');

   //      exit;
    } catch(PDOException $e) {
        echo 'Error: ' . $e->getMessage();

    }} 
}
 


 
?> 
<div class="container">
  <h4 class="mb-3">CONTACTOS </h4>

<form action="" method="post"  > 
<div class="row">
                        <div class="col-md-5 mb-3">
                          <label for="country">Nombres</label>
                           <input type="text" class="form-control" name="nombres" placeholder="" value="ccccccc" required style="text-transform:uppercase;" onkeyup="javascript:this.value=this.value.toUpperCase();">
                          <div class="invalid-feedback">Nombres </div>
                        </div>

                        <div class="col-md-4 mb-3">
                          <label for="state">Apellidos</label>
                            <input type="text" class="form-control" name="apellidos" placeholder="" value="ccccccccccc" required style="text-transform:uppercase;" onkeyup="javascript:this.value=this.value.toUpperCase();">
                        </div>

                        <div class="col-md-3 mb-3">
                          <label for="zip">email</label>
                            <input type="text" class="form-control" name="email" placeholder="" value="cccccccc" required style="text-transform:uppercase;" onkeyup="javascript:this.value=this.value.toUpperCase();">

                        </div> 

                        <div class="col-md-5 mb-3">
                          <label for="country">Pais</label>
                            <input type="text" class="form-control" name="pais" placeholder="" value="cccccccc" required style="text-transform:uppercase;" onkeyup="javascript:this.value=this.value.toUpperCase();">  
                        </div> 

                        <div class="col-md-5 mb-3">
                          <label for="country">fecha Arribo</label>
                            <input type="date" class="form-control" name="fechaArribo" placeholder="" value="<?php echo date("Y-m-d"); ?>"  required style="text-transform:uppercase;" onkeyup="javascript:this.value=this.value.toUpperCase();">  
                        </div> 


                        <div class="col-md-3 mb-3">
                          <label for="productoPerecible">Asunto </label>
                          <input type="text" class="form-control" name="asunto" placeholder="" value="cccccccc" required style="text-transform:uppercase;" onkeyup="javascript:this.value=this.value.toUpperCase();">
                        </div>

                        <div class="col-md-3 mb-3">
                          <label for="bienFiscalizado">Mensaje</label>
                         <textarea rows="" class="form-control" name="mensaje" required style="text-transform:uppercase;" onkeyup="javascript:this.value=this.value.toUpperCase();">sss </textarea> 
 
 
                         <input type="hidden"  name="fechaSistema" value="<?php echo date("Y-m-d"); ?>" > 
                         <input type="hidden"  name="url"  value="CCCCCCCC"  > 
                         <input type="hidden"  name="preferencia"  value="CCCCCCCCCCCC"  > 



                        </div>

                        <div class="col-md-3 mb-3"> <input type="submit" name='Agregar' value="Agregar" class="btn btn-primary btn-lg btn-block" /> </div>
  </div> 
</form>

<!---INICIO LISTADO---->
<h2>CONTACTOS</h2>
          <div class="table-responsive">
            <table class="table table-striped table-sm">
              <thead>
                <tr  align="">
                  <th>N°</th>
                  <th>nombres</th>
                  <th>apellidos</th>
                  <th>email</th>
                  <th>fechaArribo</th>
                  <th>pais</th>
                  <th>asunto</th>
                  <th>mensaje</th>
                  <th>fechaSistema</th>
                  <th>url</th>
                  <th>preferencia</th> 
                </tr>
              </thead>
              <tbody>
               
<?php
$i=1; 
$statement = $conectar->prepare("SELECT * FROM contactos");
$statement->execute(array(':codigoContacto' => 0));
$list = $statement->fetchAll(PDO::FETCH_ASSOC);
foreach($list as $col){ 
echo  "<tr><td>".$i."</td><td>".$col['nombres']."</td><td>".$col['apellidos']."</td><td>".$col['email']."</td><td>".$col['fechaArribo']."</td><td>".$col['pais']."</td><td>".$col['asunto']."</td><td>".$col['mensaje']."</td><td>".$col['fechaSistema']."</td><td>".$col['url']."</td><td>".$col['preferencia']."</td> </tr>";  $i++;
}

?>
              
              </tbody>
            </table>
          </div> 


<!---FIN LISTADO---->


</div>        



<?php
  require 'htmlPie.php'; 
?>