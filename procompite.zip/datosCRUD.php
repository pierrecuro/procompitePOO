<?php
require 'htmlCabeza.php'; 

if(isset($_POST['Asignar'])) {
    $mensajeError = '';

    $codigoEntrega = $_POST['arrayCodigoEntregas'];
    $codigoUnificado = $_POST['codigoUnificado'];
    $arrayDNI = $_POST['arrayDNI'];
    $arrayCantidad = $_POST['arrayCantidad'];

    $cierreActa='NO';
    $j=$i=0;
    while (count($arrayDNI)>$i){
          $j=0;
          while (count($codigoEntrega)>$j){
          $sqlInsert = $conectar->prepare('INSERT INTO datos (codigoEntrega, codigoUnificado, dni, cantidad, cierreActa) VALUES (:codigoEntrega,:codigoUnificado,:dni,:cantidad,:cierreActa)');
          $sqlInsert->execute(array(':codigoEntrega' => $codigoEntrega[$j],':codigoUnificado' => $codigoUnificado,':dni' => $arrayDNI[$i],':cantidad' => 
          $arrayCantidad[$j],':cierreActa' =>$cierreActa));
          $j++;
          }
    $i++;
    }
}

 
if(isset($_GET['varCodigoUnificado'])  ) {
    $codigoUnificado = trim($_GET['varCodigoUnificado']);
    $sqlcu=$conectar->prepare("SELECT count(*) FROM `datos` WHERE `codigoUnificado`=$codigoUnificado");
    $sqlcu->execute();
    $sql=$conectar->prepare("SELECT s.*,p.*,a.nombreProyecto FROM socios s,personas p, asociaciones a WHERE s.codigoUnificado='$codigoUnificado' and s.dni=p.dni and s.codigoUnificado=a.codigoUnificado");
    $sql->execute();
    
    $sqlTablaEntrega=$conectar->prepare("SELECT e.codigoEntrega,s.codigoUnificado,s.cadenaProductiva,s.sector,a.articulo,m.unidadMedida,r.marca FROM entregas e, asociaciones s, medidas m,articulos a, marcas r WHERE  s.codigoUnificado='$codigoUnificado' and a.codigoArticulo=e.codigoArticulo and m.codigoMedida=e.codigoMedida and r.codigoMarca=e.codigoMarca and s.codigoUnificado=e.codigoUnificado ORDER BY s.codigoUnificado ASC");
    $sqlTablaEntrega->execute(); 

 


$sqlCantidad=$conectar->prepare("SELECT count(*) as total FROM `datos` WHERE codigoUnificado='$codigoUnificado'");
    $sqlCantidad->execute();
    $re = $sqlCantidad->fetch(PDO::FETCH_OBJ);
 
$totalR=$re->total;
 
}

?>

<div class="container">
<div class="row">
      <div class="col-md-8 order-md-8">  


<?php 

if(isset($totalR)){

if($re->total>0) {?>
<a href="datosCRUDUpdate.php?cu=<?php echo $codigoUnificado;?>" target='_black'  class="btn btn-primary btn-lg btn-block">MODIFICAR ASIGNACIONES </a>
<?php } else{

echo "<h2 style='color:red;'>Falta Asignar las <a href='generadorCRUD.php?varCodigoUnificado=".$_GET['varCodigoUnificado']."'>ENTREGAS</a></h2> ";
} 

}?>



      <h4 class="mb-3">MODIFICACION DE ASIGNACION DE  SOCIOS:  </h4>
      <form   method="Get" class="needs-validation" novalidate> 
            <div class="col-md-6 mb-6">
                  <div class="input-group">
                    <div class="input-group-prepend"><span class="input-group-text"> CODIGO UNIFICADO</span></div>

                    <input class="form-control" type="number" id="CU" name='varCodigoUnificado' placeholder="Antes Código SIAF" required min="1" pattern="^[0-9]+" onpaste="return true;" onDrop="return false;" autocomplete=off>
              
                  </div>  
            </div>
            <div class="col-md-3 mb-3">
                  <div class="input-group"> 
                        <input type="submit" name='buscar' value="Buscar" class="btn btn-primary btn-lg btn-block" />  
                        <a href='datosCRUD.php'" class="btn btn-primary btn-lg btn-block">nuevo</a>
                   </div>
            </div>
            
      </form>
      </div>
</div>

 
 

          
</div>



 

 


 
<?php
  require 'htmlPie.php'; 
?>