<?php
include('config.php');
/*
$stmt=$db_con->prepare('select * from books');
$stmt->execute();
*/
//$cu='2158880';

  $cu = $_GET['cu'];
/*
$stmt=$conectar->prepare("SELECT   @rownum:=@rownum+1 AS Nro,p.dni,s.condicion,p.aPaterno,p.aMaterno,p.nombres,so.nombreProyecto from (SELECT @rownum:=0) num,datos d,socios s, entregas e, articulos a,personas p,asociaciones so where e.codigoUnificado='$cu' and e.codigoEntrega=d.codigoEntrega and a.codigoArticulo=e.codigoArticulo and p.dni=d.dni and p.dni=s.dni and so.codigoUnificado=d.codigoUnificado
group by p.dni");

 
*/
$stmt=$conectar->prepare("SELECT  p.dni,m.margesi,p.aPaterno,p.aMaterno,p.nombres,so.nombreProyecto from  margesi m, datos d,socios s, entregas e, articulos a,personas p,asociaciones so where e.codigoUnificado='$cu' and e.codigoEntrega=d.codigoEntrega and a.codigoArticulo=e.codigoArticulo and p.dni=d.dni and p.dni=s.dni and so.codigoUnificado=d.codigoUnificado  and s.codigoMargesi=m.codigoMargesi group by p.dni");



//

$stmt->execute();

 

if(isset($_POST['arrayCodigoDato'])) {
        //print_r ($_POST);
        $arrayCodigoDato= $_POST['arrayCodigoDato'];
        $arrayCantidad= $_POST['arrayCantidad'];
        /*echo "<br>codigo:".$arrayCodigoDato[1];
        echo "<br>cantidad:".$arrayCantidad[1]."<br>"; 
       */
        $x=0; 
    while ($x<count($arrayCodigoDato)){  
        $sqlModificar = $conectar->prepare("UPDATE `datos` SET `cantidad` = '$arrayCantidad[$x]' WHERE `codigoDato` = $arrayCodigoDato[$x]");
        $sqlModificar->execute();
        $x++;
    } 

 }

$gsent = $conectar->prepare("SELECT * FROM asociaciones where codigoUnificado='$cu'");
$gsent->execute();
$result = $gsent->fetch(PDO::FETCH_OBJ);

 

$nRows = $conectar->prepare("SELECT count(*)  FROM entregas WHERE codigoUnificado='$cu'")->fetchColumn(); 
// $nRows;

 
$nRows =$conectar->prepare("SELECT count(*)  FROM entregas WHERE codigoUnificado='$cu'"); 
$nRows->execute(); 
$numeroRows = $nRows->fetchColumn()+6; 

 
/*
$sql=$conectar->prepare("SELECT e.codigoEntrega,a.articulo,m.unidadMedida,d.marca FROM entregas e, articulos a, medidas m, marcas d WHERE e.codigoUnificado='$cu' and e.codigoArticulo=a.codigoArticulo and e.codigoMedida=m.codigoMedida and d.codigoMarca= e.codigoMarca");
$sql->execute();

 */

 

  $sql = $conectar->prepare("SELECT e.codigoEntrega,a.articulo,m.unidadMedida,d.marca,m.unidadMedida FROM entregas e, articulos a, medidas m, marcas d WHERE e.codigoUnificado='$cu' and e.codigoArticulo=a.codigoArticulo and e.codigoMedida=m.codigoMedida and d.codigoMarca= e.codigoMarca");
$sql->execute();
$listaMarcaArticulo = $sql->fetchAll(PDO::FETCH_ASSOC);



//echo intval($nroTotal, 6);
$i=1;
?>

<!DOCTYPE html>
<html lang="en">

 <meta http-equiv="content-type" content="text/html;charset=utf-8" /> 
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <link href='css/reportes.css' type='text/css' rel='stylesheet' > 
</head>
<body> 

<div class="container">
  <div class="panel">
    <div class="panel-heading"> 
      <div class="panel-body">

<form action="" method="post"  >

<input type="submit" name="Modificar" value="modicar" class="btn btn-primary btn-lg btn-block" />

         <table border="1" id="testTable" class="table table-bordered table-striped">

                      <tr>
              <td colspan="<?php echo $numeroRows;?>"><b>MUNICIPALIDAD DISTRITAL DE ECHARATI</b></td>
            </tr>
            <tr>
              <td colspan="<?php echo $numeroRows;?>" width='900'><?php echo "<b>nombre Proyecto : ".$result->nombreProyecto;?></td>
            </tr>
            <tr>
              <td colspan="<?php echo $numeroRows;?>" width='900'><?php echo "<b>nombre Corto :</b><b style='color:red;'> ".$result->sector." ".$result->cadenaProductiva."</b>";?> -  <?php echo "codigo Unificado : <b style='color:green;'>".$result->codigoUnificado."</b> ";?></td>
            </tr>
            <tr>
              <td colspan="<?php echo $numeroRows;?>" width='900'><?php echo "<b>Convocatoria : #</b>".$result->convocatoria;?></td>
            </tr>
            <tr>
              <td colspan="<?php echo $numeroRows;?>" width='900'><?php echo "<b>Resolución : </b>".$result->resolucion;  echo "<b> fecha Resolución : </b>".$result->fechaResolucion;  ?></td>
            </tr>
            <tr>
              <td ></td>
            </tr>
            
          
                   <tr>
              <td colspan="6"></td>
                <?php
                foreach($listaMarcaArticulo as $obj){ 
                echo '<td>&nbsp; '.$obj['unidadMedida'].' </td> ';
                }
                ?>
            </tr>
          
    				<tr>
    					<th>Nro.</th>
    					<th>DNI</th>
    					<th>condicion</th>
              <th>aPaterno</th>
              <th>aMaterno</th>
              <th>nombres</th> 
                <?php
                foreach($listaMarcaArticulo as $objeto){ 
                echo '<td>&nbsp; '.$objeto['articulo'].' </td> ';
                }/*
                while($rows=$sql->FETCH(PDO::FETCH_ASSOC)){
                echo '<th>&nbsp;<div class=rotar>'.$rows["articulo"].'</div></th> ';
                }*/
                ?>
    				</tr>


    			<?php
    
          while($row=$stmt->FETCH(PDO::FETCH_ASSOC)){
            $dni=$row["dni"];
            echo '
            <tr>
              <td>'.$i++.'</td>
              <td>'.$row["dni"].'</td>
              <td>'.$row["margesi"].'</td>
              <td>'.$row["aPaterno"].'</td>
              <td>'.$row["aMaterno"].'</td>
              <td>'.$row["nombres"].'</td>
            ';


              $sqlColumna=$conectar->prepare("SELECT d.cantidad,d.codigoDato  FROM  datos d,entregas e  WHERE d.codigoUnificado='$cu' and d.dni='$dni' and e.codigoEntrega=d.codigoEntrega");
              $sqlColumna->execute();
                
              while($rowc=$sqlColumna->FETCH(PDO::FETCH_ASSOC)){
              echo '<td><input  type="hidden"  name="arrayCodigoDato[]" value="'.$rowc["codigoDato"].'"><input  type="text"  name="arrayCantidad[]" value="'.$rowc["cantidad"].'"></td>'; 
              }
           

          echo '</tr>';

          }

 

 echo '<tr><td colspan=6 class=derecha >total</td>';


$sqlTotal=$conectar->prepare("SELECT  COUNT(*) total_repetidos, sum(cantidad) as subTotal, codigoEntrega 
FROM datos WHERE codigoUnificado='$cu'
GROUP By codigoEntrega 
HAVING total_repetidos > 1");
$sqlTotal->execute();

while($rowt=$sqlTotal->FETCH(PDO::FETCH_ASSOC)){
echo '<td>'.$rowt["subTotal"].'</td>';
}

echo '</tr>';



    			?>
    		</table> 
<input type="submit" name="Modificar" value="modicar" class="btn btn-primary btn-lg btn-block" />
</form>

      </div>

    </div>

  </div>

</div>



</body>
</html>
