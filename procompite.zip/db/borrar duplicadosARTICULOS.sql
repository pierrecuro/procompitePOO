duplicados
___________________________________________________________________________________________________


SELECT * FROM `socios` WHERE dni='00162181'
SELECT * FROM `socios` WHERE dni='00517480' 

SELECT * FROM `socios` WHERE dni='23840378' 

SELECT COUNT(*) total_repetidos, dni FROM socios GROUP By dni HAVING total_repetidos > 1

SELECT COUNT(*) total_repetidos, s.dni,p.aPaterno,p.aMaterno,p.nombres,p.fechaNacimiento FROM socios s,personas p  where s.dni=p.dni GROUP By s.dni HAVING total_repetidos > 1


					<?php
					$i=1;
					$sqlPDO = $conectar->prepare("SELECT COUNT(*) total_repetidos, dni FROM socios GROUP By dni HAVING total_repetidos > 1");
					$sqlPDO->execute(array(':codigoArticulo' => 0));
					$lista = $sqlPDO->fetchAll(PDO::FETCH_ASSOC);
					foreach($lista as $obj){ 
					echo  "<tr><td>".$i."</td><td>".$obj['codigoArticulo']."</td><td>".$obj['articulo']."</td> <td>".$obj['margesi']."</td> <td>".$obj['bienFiscalizado']."</td>      <td> <a href=?editar=".$obj['codigoArticulo'].">Editar</a></td>  </tr>";  $i++;
					}?>


BORRADOS
___________________________________________________________________________________________________
42 HORNO SEMIINDUSTRIAL A GAS
24 PLATOS DE LOZA COLOR BLANCO PLANOS
34 PLATOS DE LOZA COLOR BLANCO (PARA ENSALADA DE FRUTas)
23 PLATOS DE LOZA COLOR BLANCO GRANDES (PARA EXTRAS)
56 SUPLEMENTO VITAMINICO Y MINERA
67 ARPILLERA  2 METROS DE ANCHO  X 100
104 PLANTULAS DE MANI FORRAJERO DE 0.20
124 VACUNA PARA VIRUELA/1000 DOSIS
135 VACUNA PARA VIRUELA/1000 DOSIS
156 POLLOS BB PARRILLEROS COBB 500 CAJA X 100 UNIDADES
141 ALIMENTO BALANCEADO PARA ACABADO
137 ALIMENTO BALANCEADO PARA CRECIMIENTO
133 ALIMENTO BALANCEADO PARA INICIO

SELECT COUNT(*) total_repetidos, articulo 
FROM articulos 
GROUP By articulo 
HAVING total_repetidos > 1

___________________________________________________________________________________________________

SELECT COUNT(*) total_repetidos, dni 
FROM personas
GROUP By dni 
HAVING total_repetidos > 1

DELETE t1 FROM personas t1
INNER JOIN personas t2 
WHERE t1.codigoPersonal > t2.codigoPersonal AND t1.dni = t2.dni; 


 
pivot
_______________________________________________________________________________
SELECT p.dni,s.condicion,p.aPaterno,p.aMaterno,p.nombres, 
sum(d.cantidad*(1-abs(sign(d.codigoEntrega-12)))) as 'UNIFORME DE AYUDANTE',
sum(d.cantidad*(1-abs(sign(d.codigoEntrega-10)))) as 'MESA DE TRABAJO DE 2 NIVELES EN ACERO INOXIDABLE',
sum(d.cantidad*(1-abs(sign(d.codigoEntrega-14)))) as 'OLLA A PRESION DE 14 LITROS' 
from datos d,socios s, entregas e, articulos a,personas p where e.codigoUnificado='2158881' and e.codigoEntrega=d.codigoEntrega and a.codigoArticulo=e.codigoArticulo and p.dni=d.dni and p.dni=s.dni
group by p.dni


CREATE VIEW v_today (today) AS SELECT CURRENT_DATE;

create view pivot (@cu) as (
SET @cu
SELECT p.dni,s.condicion,p.aPaterno,p.aMaterno,p.nombres, 
sum(d.cantidad*(1-abs(sign(d.codigoEntrega-12)))) as 'UNIFORME DE AYUDANTE',
sum(d.cantidad*(1-abs(sign(d.codigoEntrega-10)))) as 'MESA DE TRABAJO DE 2 NIVELES EN ACERO INOXIDABLE',
sum(d.cantidad*(1-abs(sign(d.codigoEntrega-14)))) as 'OLLA A PRESION DE 14 LITROS' 
from datos d,socios s, entregas e, articulos a,personas p where e.codigoUnificado='@cu' and e.codigoEntrega=d.codigoEntrega and a.codigoArticulo=e.codigoArticulo and p.dni=d.dni and p.dni=s.dni
group by p.dni


  );  

SELECT "2158881" FROM pivot;


 
codigoSocio  
dni
cargo
condicion
tipoSocio
codigoUnificado

SELECT COUNT(*) total_repetidos, codigoUnificado FROM socios GROUP By codigoUnificado HAVING total_repetidos > 1



SELECT COUNT(*) total_repetidos, dni FROM datos GROUP By dni HAVING total_repetidos > 1



SELECT p.dni,s.condicion,p.aPaterno,p.aMaterno,p.nombres
from datos d,socios s, entregas e, articulos a,personas p where e.codigoUnificado='2158881' and e.codigoEntrega=d.codigoEntrega and a.codigoArticulo=e.codigoArticulo and p.dni=d.dni and p.dni=s.dni
group by p.dni



SELECT *
from datos D
inner join (SELECT * FROM entregas E WHERE D.codigoEntrega = D.codigoEntrega)

SELECT * from datos D inner join entregas E ON E.codigoEntrega = D.codigoEntrega

SELECT DISTINCT D.dni, D.codigoEntrega from datos D 


SELECT COUNT(*) total_repetidos, codigoEntrega 
FROM datos
GROUP By codigoEntrega 
HAVING total_repetidos > 1


SELECT suma(*) total_repetidos, codigoEntrega 
FROM datos WHERE codigoUnificado='2158880'
GROUP By codigoEntrega 
HAVING total_repetidos > 1



SELECT D.*
from datos D
inner join 
(SELECT COUNT(*) total_repetidos, codigoEntrega 
FROM datos
GROUP By codigoEntrega 
HAVING total_repetidos > 1) X on D.dni = X.dni 






 
SELECT COUNT(*) total_repetidos, dni 
FROM datos
GROUP By dni 
HAVING total_repetidos > 1

SELECT e.codigoEntrega,a.articulo,m.unidadMedida,d.marca FROM entregas e, articulos a, medidas m, marcas d WHERE e.codigoUnificado='2158881' and e.codigoArticulo=a.codigoArticulo and  e.codigoMedida=m.codigoMedida and d.codigoMarca= e.codigoMarca