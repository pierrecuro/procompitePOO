<?php
require 'htmlCabeza.php';  


if(isset($_POST['Agregar'])) {
		$mensajeError = '';
		$articulo = trim($_POST['articulo']); 
	 
		$codigoMargesi = $_POST['codigoMargesi'];
		$bienFiscalizado = $_POST['bienFiscalizado']; 

		if($articulo == '') $mensajeError = 'articulo';
		if($mensajeError == ''){ try {
		// print_r($_POST);
		$sql = $conectar->prepare('INSERT INTO articulos (codigoArticulo, articulo,  codigoMargesi, bienFiscalizado) VALUES (codigoArticulo,:articulo,:codigoMargesi,:bienFiscalizado)');

		$sql->execute(array(':articulo' => $articulo,':codigoMargesi' => $codigoMargesi,':bienFiscalizado' => $bienFiscalizado));
		echo "<center>fue grabado</center>";
		 
		} 	catch(PDOException $e) {
		echo "<center>error</center>";


		}} 
}


if(isset($_GET['eliminar'])) {
		$codigoArticulo= $_GET['eliminar'];
		$sqlDelete = $conectar->prepare("DELETE FROM articulos WHERE codigoArticulo = ?");
		$sqlDelete->execute([$codigoArticulo]);
		$sqlDelete = null;
}


if(isset($_GET['editar'])) {
		$codigoArticulo= $_GET['editar']; 
		$sqlSelect = $conectar->prepare("SELECT * FROM `articulos` WHERE `codigoArticulo`= ?");
		$sqlSelect->execute([$codigoArticulo]);
		$unRegistro = $sqlSelect->fetch(PDO::FETCH_LAZY);
		if(!$unRegistro) exit('no hay registros');
		/*similares muestras de registros echo $unRegistro[0];echo $unRegistro->producto; echo $unRegistro['producto'];*/
		$sqlSelect = null;
}

 
if(isset($_POST['Modificar'])) {
		$codigoArticulo= $_POST['codigoArticulo'];
		$articulo = trim($_POST['articulo']);  
		$codigoMargesi = $_POST['codigoMargesi'];
		$bienFiscalizado = $_POST['bienFiscalizado'];
		$sqlModificar = $conectar->prepare("UPDATE `articulos` SET `articulo` = '$articulo', `codigoMargesi` = '$codigoMargesi', `bienFiscalizado` = '$bienFiscalizado' WHERE `codigoArticulo` = $codigoArticulo");
		$sqlModificar->execute([$codigoArticulo]);
		$sqlModificar = null;
		header('Location: articulosCRUD.php?action=2');
}

 
 
$tablaMargesiTipo = $conectar->prepare("SELECT * FROM `margesi` WHERE `tipo`='TIPO'");
$tablaMargesiTipo->setFetchMode(PDO::FETCH_ASSOC);
$tablaMargesiTipo->execute(); 

$tablaMargesiActivo = $conectar->prepare("SELECT * FROM `margesi` WHERE `tipo`='ACTIVO'");
$tablaMargesiActivo->setFetchMode(PDO::FETCH_ASSOC);
$tablaMargesiActivo->execute(); 

 
?> 
<div class="container">
  <h4 class="mb-3">DUPLICADOS</h4>
 

<!---INICIO LISTADO---->
          <div class="table-responsive">
            <table class="table table-striped table-sm">
              <thead>
                <tr  align="">
                  <th>N°</th>
                  <th>dni</th>
                  <th></th> 
                  <th>Paterno</th> 
                  <th>Materno</th>  
                  <th>Nombres</th>  
                  <th> </th>   
                </tr>
              </thead>
              <tbody>                 
					<?php
					$i=1;
					$sqlPDO = $conectar->prepare("SELECT COUNT(*) cantidaDuplicados, s.dni,p.aPaterno,p.aMaterno,p.nombres,p.fechaNacimiento FROM socios s,personas p where s.dni=p.dni GROUP By s.dni HAVING cantidaDuplicados > 1");
                    $sqlPDO->execute(array(':dni' => 0));
					$lista = $sqlPDO->fetchAll(PDO::FETCH_ASSOC);



                    foreach($lista as $obj){  
					echo  "<tr><td><b>".$i."</b></td><td>".$obj['dni']."</td>  <td><b>Condición</b></td> <td>".$obj['aPaterno']."</td> <td>".$obj['aMaterno']."</td> <td>".$obj['nombres']."</td><td><b>Cargo</b></td> </tr>"; 
 
$varDNI=$obj['dni']; 
$sql = $conectar->prepare("SELECT s.*,a.sector,a.cadenaProductiva, m.margesi FROM socios s,asociaciones a,margesi m WHERE s.codigoUnificado=a.codigoUnificado and m.codigoMargesi=s.codigoMargesi and s.dni='$varDNI'");
$sql->execute(array(':dni' => 0));
$subLista = $sql->fetchAll(PDO::FETCH_ASSOC);
$a=1;
foreach($subLista as $row){  

echo  "<tr colspan='7'><td>".$row['codigoSocio']."</td><td> </td> <td>".$row['margesi']."</td> <td colspan='3'>"."<b>CU:</b>".$row['codigoUnificado']." - <b>Sector:</b>".$row['sector']." -  ".$row['cadenaProductiva']." </td> <td>  ".$row['cargo']."</td> </tr>"; $a++;
}
$i++;


					}
                    ?>
              </tbody>
            </table>
          </div> 
<!---FIN LISTADO---->


</div>        
 
<?php
  require 'htmlPie.php'; 
?>