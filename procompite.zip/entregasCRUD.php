<?php
require 'htmlCabeza.php';  
//print_r($_POST);

$AgregarMas=0;
if(isset($_POST['Agregar'])) {
		$mensajeError = '';
		$codigoUnificado = $_POST['codigoUnificado'];
		$codigoArticulo = $_POST['codigoArticulo'];
		$codigoMedida = $_POST['codigoMedida'];
        $codigoMarca = $_POST['codigoMarca']; 
        $fechaCreacion = date("Y-m-d");    

        $historialUsuario=$_SESSION['dni'];

		if($mensajeError == ''){ try {
		
		$sql = $conectar->prepare('INSERT INTO entregas (codigoUnificado, codigoArticulo, codigoMedida, codigoMarca, fechaCreacion, historialUsuario) VALUES (:codigoUnificado,:codigoArticulo,:codigoMedida,:codigoMarca,:fechaCreacion,:historialUsuario)');
		$sql->execute(array(':codigoUnificado' => $codigoUnificado,':codigoArticulo' => $codigoArticulo,':codigoMedida' => $codigoMedida,':codigoMarca' => $codigoMarca,':fechaCreacion' => $fechaCreacion,':historialUsuario' => $historialUsuario));
		//header('Location: entregasCRUD.php?action=1');
		//exit;

        $sqlSelecto = $conectar->prepare("SELECT a.articulo,s.cadenaProductiva,s.sector,s.nombreProyecto,e.* FROM articulos a,entregas e,asociaciones s WHERE a.codigoArticulo=e.codigoArticulo and s.codigoUnificado=e.codigoUnificado ORDER BY `e`.`codigoEntrega` DESC limit 1"); 
        $sqlSelecto->execute();
        $masRegistro = $sqlSelecto->fetch(PDO::FETCH_LAZY);
        if(!$masRegistro) exit('no hay registros'); 
        $sqlSelecto = null;
        $AgregarMas=$masRegistro->codigoEntrega;
        $masRegistro->codigoUnificado;

 

		} catch(PDOException $e) {
		echo $e->getMessage();
		}} 
}


if(isset($_GET['eliminar'])) {
		$codigoEntrega= $_GET['eliminar'];
		$sqlDelete = $conectar->prepare("DELETE FROM entregas WHERE codigoEntrega = ?");
		$sqlDelete->execute([$codigoEntrega]);
		$sqlDelete = null;
}


if(isset($_GET['editar'])) {
		$codigoEntrega= $_GET['editar']; 
		//$sqlSelect = $conectar->prepare("SELECT a.articulo,e.* FROM articulos a,entregas e WHERE a.codigoArticulo=e.codigoArticulo and e.codigoEntrega= ?");
		$sqlSelect = $conectar->prepare("SELECT a.articulo,s.cadenaProductiva,s.sector,s.nombreProyecto,e.* FROM articulos a,entregas e,asociaciones s WHERE a.codigoArticulo=e.codigoArticulo and s.codigoUnificado=e.codigoUnificado and e.codigoEntrega= ?"); 
		$sqlSelect->execute([$codigoEntrega]);
		$unRegistro = $sqlSelect->fetch(PDO::FETCH_LAZY);
		if(!$unRegistro) exit('no hay registros');
		/*similares muestras de registros echo $unRegistro[0];echo $unRegistro->producto; echo $unRegistro['producto'];*/
		$sqlSelect = null;
}


if(isset($_POST['Modificar'])) {
	$codigoEntrega= $_POST['codigoEntrega'];
	$codigoUnificado = $_POST['codigoUnificado'];
	$codigoArticulo = $_POST['codigoArticulo'];
	$codigoMedida = $_POST['codigoMedida'];
	$codigoMarca = $_POST['codigoMarca']; 
	$sqlModificar = $conectar->prepare("UPDATE `entregas` SET `codigoUnificado` = '$codigoUnificado', `codigoArticulo` = '$codigoArticulo', `codigoMedida` = '$codigoMedida', `codigoMarca` = '$codigoMarca' WHERE `codigoEntrega` = $codigoEntrega");
	$sqlModificar->execute([$codigoEntrega]);
	$sqlModificar = null;
	///header('Location: entregasCRUD.php?action=2');
}


	 
	$tablaArticulos = $conectar->prepare("SELECT * FROM `articulos`");
	$tablaArticulos->setFetchMode(PDO::FETCH_ASSOC);
	$tablaArticulos->execute(); 

	$tablaMedidas = $conectar->prepare("SELECT * FROM `medidas` ");
	$tablaMedidas->setFetchMode(PDO::FETCH_ASSOC);
	$tablaMedidas->execute();

	$tablaMarcas = $conectar->prepare("SELECT * FROM `marcas`");
	$tablaMarcas->setFetchMode(PDO::FETCH_ASSOC);
	$tablaMarcas->execute(); 
 
?> 




    <script type="text/javascript">
    $(document).ready(function(){
                $(document).on('keydown', '.sector', function() {
                    var codigoAsociacion = this.id;
                    var splitid = codigoAsociacion.split('_');
                    var index = splitid[1];
                            $( '#'+codigoAsociacion ).autocomplete({
                                source: function( request, response ) {
                                    $.ajax({
                                        url: "entregasAjaxAsociacion.php",
                                        type: 'post',
                                        dataType: "json",
                                        data: {
                                            search: request.term,request:1
                                        },
                                        success: function( data ) {
                                            response( data );
                                        }
                                    });
                                },
                                select: function (event, ui) {
                                    $(this).val(ui.item.label); // display the selected text
                                    var varcodigoAsociacion = ui.item.value; // selected id to input
                                    // AJAX
                                    $.ajax({
                                        url: 'entregasAjaxAsociacion.php',
                                        type: 'post',
                                        data: {varcodigoAsociacion:varcodigoAsociacion,request:2},
                                        dataType: 'json',
                                        success:function(response){
                                            var len = response.length;
                                            if(len > 0){
                                                var codigoAsociacion = response[0]['codigoAsociacion'];
                                                var nombreProyecto = response[0]['nombreProyecto'];
                                                var codigoUnificado = response[0]['codigoUnificado'];
                                                var cadenaProductiva = response[0]['cadenaProductiva'];
                                                var sector = response[0]['sector'];
                                                document.getElementById('nombreProyecto_'+index).value = nombreProyecto;
                                                document.getElementById('codigoAsociacion_'+index).value = codigoAsociacion;
                                                document.getElementById('codigoUnificado_'+index).value = codigoUnificado;
                                                document.getElementById('cadenaProductiva_'+index).value = cadenaProductiva;
                                                document.getElementById('sector_'+index).value = sector; 
                                            }
                                        }
                                    });
                                    return false;
                                }
                            });
                });
    });
    </script>



    <script type="text/javascript">
    $(document).ready(function(){
                $(document).on('keydown', '.articulo', function() {
                    var codigoArticulo = this.id;
                    var splitid = codigoArticulo.split('_');
                    var index = splitid[1];
                            $( '#'+codigoArticulo ).autocomplete({
                                source: function( request, response ) {
                                    $.ajax({
                                        url: "entregasAjaxArticulo.php",
                                        type: 'post',
                                        dataType: "json",
                                        data: {
                                            search: request.term,request:1
                                        },
                                        success: function( data ) {
                                            response( data );
                                        }
                                    });
                                },
                                select: function (event, ui) {
                                    $(this).val(ui.item.label); // display the selected text
                                    var varCodigoArticulo = ui.item.value; // selected id to input
                                    // AJAX
                                    $.ajax({
                                        url: 'entregasAjaxArticulo.php',
                                        type: 'post',
                                        data: {varCodigoArticulo:varCodigoArticulo,request:2},
                                        dataType: 'json',
                                        success:function(response){
                                            var len = response.length;
                                            if(len > 0){
                                                var codigoArticulo = response[0]['codigoArticulo'];
                                                var articulo = response[0]['articulo'];
                                                document.getElementById('articulo_'+index).value = articulo;
                                                document.getElementById('codigoArticulo_'+index).value = codigoArticulo;
                                            }
                                        }
                                    });
                                    return false;
                                }
                            });
                });
    });
    </script>






<div class="container">
  <h4 class="mb-3">ENTREGAS</h4>

<form action="" method="post"  > 
<div class="row">

<?php 

if ($AgregarMas=='0') {
    
?>
                         <div class="col-md-10 mb-3">
                            <label for="country">Sector - Codigo Unificado</label><br>
                            <input type='text'    autofocus  required="required" style="width: 450px !important; "   class='sector' id='sector_1' placeholder='buscar Sector' value="<?php if(isset($_GET['editar'])) {  echo $unRegistro->sector; }?>">
                            <input type='hidden'  id='codigoAsociacion_1' disabled >
                            <input type='text'  id='cadenaProductiva_1' disabled  value="<?php if(isset($_GET['editar'])) {  echo $unRegistro->cadenaProductiva; }?>"> 
                            - 
                            <input type='text' name='codigoUnificado' id='codigoUnificado_1' readonly=”readonly”  value="<?php if(isset($_GET['editar'])) {  echo $unRegistro->codigoUnificado; }?>">
                            <input type='text'   id='nombreProyecto_1' disabled style="width: 900px !important; font-size: 9px;"  value="<?php if(isset($_GET['editar'])) {  echo $unRegistro->nombreProyecto; }?>">
                        </div>
 <?php
    }else{
        //echo "ss".$masRegistro->sector; 
?>    
 
                        <div class="col-md-10 mb-3">
                            <label for="country">Sector - Codigo Unificado</label><br>
                            <input type='text'  required="required" style="width: 450px !important; "   class='sector' id='sector_1' placeholder='buscar Sector' value="<?php if(isset($AgregarMas)) {  echo $masRegistro->sector; }?>">
                            <input type='hidden'  id='codigoAsociacion_1' disabled >
                            <input type='text'  id='cadenaProductiva_1' disabled  value="<?php if(isset($AgregarMas)) {  echo $masRegistro->cadenaProductiva; }?>"> 
                            - 
                            <input type='text' name='codigoUnificado' id='codigoUnificado_1' readonly=”readonly”  value="<?php if(isset($AgregarMas)) {  echo $masRegistro->codigoUnificado; }?>">
                            <input type='text'   id='nombreProyecto_1' disabled style="width: 900px !important; font-size: 9px;"  value="<?php if(isset($AgregarMas)) {  echo $masRegistro->nombreProyecto; }?>">
                        </div>  
<?php    
 
} ?>



						<div class="col-md-10 mb-3 ">
							<label for="country">Articulo</label>
							<input type='text'  <?php if ($AgregarMas!='0') { echo "autofocus";}?> class='articulo form-control' id='articulo_1' required="required"  placeholder='buscar articulo' value="<?php if(isset($_GET['editar'])) {  echo $unRegistro->articulo; }?>" >
							<input type='text' name='codigoArticulo'  id='codigoArticulo_1' value="<?php if(isset($_GET['editar'])) {  echo $unRegistro->codigoArticulo; }?>" >
						</div>
 
 <?php 

if ($AgregarMas=='0') {
    
?>
                        <div class="col-md-3 mb-3">
                          <label for="zip">Medida</label>
                           <select class="custom-select d-block w-100"  name="codigoMedida"   required="">
                                <?php while ($row = $tablaMedidas->fetch()){?> 
                                <option value="<?php echo $row['codigoMedida'];?>" <?php  
                                if(isset($_GET['editar'])) {
                                if ($row['codigoMedida']==$unRegistro['codigoMedida']) {echo "selected"; }
                                }?> > <?php echo $row['unidadMedida']; ?>- <?php echo $row['codigoMedida']; ?></option>
                                <?php } ?>
                          </select>
                        </div> 
 <?php
    }else{ 
?>    
                         <div class="col-md-3 mb-3">
                          <label for="zip">Medida</label>
                           <select class="custom-select d-block w-100"  name="codigoMedida"   required="">
                                <?php while ($row = $tablaMedidas->fetch()){?> 
                                <option value="<?php echo $row['codigoMedida'];?>" <?php  
                                if(isset($AgregarMas)) {
                                if ($row['codigoMedida']==$masRegistro['codigoMedida']) {echo "selected"; }
                                }?> > <?php echo $row['unidadMedida']; ?></option>
                                <?php } ?>
                          </select>
                        </div> 
<?php    
 
} ?>



                        <div class="col-md-5 mb-3">
                          <label for="country">Marcas</label>
                          <select class="custom-select d-block w-100"  name="codigoMarca"   required="">
								<?php while ($row = $tablaMarcas->fetch()){?> 
								<option value="<?php echo $row['codigoMarca'];?>" <?php  
								if(isset($_GET['editar'])) {
								if ($row['codigoMarca']==$unRegistro['codigoMarca']) {echo "selected"; }
								}?> > <?php echo $row['marca']; ?>
								</option>
								<?php } ?>                            
                          </select>
                        </div> 
						<div class="col-md-2 mb-3">

						</div> 


<div class="col-md-3 mb-3">
<?php if(isset($_GET['editar'])) {?>
<input type="submit" name='Modificar' value="modicar" class="btn btn-primary btn-lg btn-block" /> 
<input type="hidden"  name="codigoEntrega"  value="<?php if(isset($_GET['editar'])) {  echo $unRegistro->codigoEntrega; }?>" > 
<?php  } else {  ?>
<input type="submit" name='Agregar' value="Agregar" class="btn btn-primary btn-lg btn-block" />
<?php  }?>
</div>
<div class="col-md-2 mb-2">
<a href="entregasCRUD.php" class="btn btn-primary btn-lg btn-block" style="background: #fff !important;color: #000 !important;" />Nuevo</a>
</div>

  </div> 
</form>

<!---INICIO LISTADO---->
<h2>LISTA DE ENTREGAS</h2>
          <div class="table-responsive">
            <table class="table table-striped table-sm">
              <thead>
                <tr  align="">
                  <th>N°</th>
                  <th>sector</th>
                  <th>codigo Unificado</th>
                  <th>articulo</th>
                  <th>unidad Medida</th> 
                  <th>marca</th>  
                  <th> </th>  
                  <th>cantidad Referencial</th>  
                </tr>
              </thead>
              <tbody>                 
					<?php 

                     $fechaHoy = date("Y-m-d");  

					$i=1;
					$sqlPDO = $conectar->prepare("SELECT e.cantidadReferencial,e.fechaCreacion,e.codigoEntrega,s.codigoUnificado,s.cadenaProductiva,s.sector,a.articulo,m.unidadMedida,r.marca,s.cierreActa FROM entregas e, asociaciones s, medidas m,articulos a, marcas r WHERE a.codigoArticulo=e.codigoArticulo and m.codigoMedida=e.codigoMedida and r.codigoMarca=e.codigoMarca and s.codigoUnificado=e.codigoUnificado    ORDER BY e.codigoEntrega DESC");
//and e.fechaCreacion='$fechaHoy'

					$sqlPDO->execute(array(':codigoArticulo' => 0));
					$lista = $sqlPDO->fetchAll(PDO::FETCH_ASSOC);
					foreach($lista as $obj){ 
					echo  "<tr><td>".$i."</td><td>".$obj['cadenaProductiva']." <br><b> ".$obj['sector']."</b></td><td><b>".$obj['codigoUnificado']."</b></td><td>".$obj['articulo']."</td> <td>".$obj['unidadMedida']."</td> <td>".$obj['marca']."</td>      <td>";

if($obj['cierreActa']=='NO'){
					echo "<a href=?eliminar=".$obj['codigoEntrega'].">Eliminar</a><br><a href=?editar=".$obj['codigoEntrega'].">Editar</a>";
}

                    echo "</td> <td>".$obj['cantidadReferencial']."</td> </tr>";  $i++;
					}?>
              </tbody>
            </table>
          </div> 
<!---FIN LISTADO---->


</div>        
 
<?php
  require 'htmlPie.php'; 

?>