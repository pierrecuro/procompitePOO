<?php
  require 'config.php';
  if(empty($_SESSION['nombreCompleto']))
    header('Location: index.php');
  $codigoUsuarioSession=$_SESSION['codigoUsuario'];

?>
<!doctype html>
<html lang="en">
  <head>
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
            <meta name="description" content="">
            <meta name="author" content="">
            
            <link rel="icon"     href="imagen/ico.png">
            <link rel="icon"  sizes="1x1"  href="imagen/ico.png"> 
            <title>warehouse</title>
            <!-- Bootstrap core CSS -->
            <link href="css/bootstrap.min.css" rel="stylesheet">
            <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
            <script>window.jQuery || document.write('<script src="js/vendor/jquery-slim.min.js"><\/script>')</script>
            <script src="js/vendor/popper.min.js"></script>
            <script src="js/bootstrap.min.js"></script>
            <!-- Custom styles for this template -->
            <link rel="stylesheet" href="css/menus.css">
            <script src="css/menus.js"></script>
            <!-- autocompletar -->

    <link href='css/autocompletar.css' type='text/css' rel='stylesheet' >
    <script src="js/jquery-3.2.1.min.js" type="text/javascript"></script>
    <script src="js/autocompletar.js" type="text/javascript"></script>
 



  </head>
  <body>

<nav class="  navbar-expand-lg navbar-dark bg-dark">
<div class="container">
<div id='cssmenu'>
        <?php  
        function funcionMenu($item) 
        { 
            global $conectar; 
            $subsel = $conectar->prepare('SELECT *  FROM menus WHERE indice = :parent and activo="1" ORDER BY orden'); 
            $subsel->execute(array('parent' => $item)); 
            $text = ''; 
                foreach ($subsel as $i) { 
                $text .= '<li class="active has-sub"><a   href="' . $i['url']. '"><span>' . htmlspecialchars($i['menu']) . '</span></a>' 
                    . funcionMenu($i['codigoMenu']) . '</li>'; 
                } 
            if ($text == '') { 
                return ''; 
            } 
            return '<ul >' . $text . '</ul>'; 
        } 
        echo funcionMenu(0);  
        ?>
         
</div>
    <div style="color: #fff; " ><?php echo $_SESSION['nombreCompleto']; ?></div>
</div>
</nav> 