<?php
  require 'config.php';

  if(isset($_POST['login'])) {
    $mensajeError = '';

    // Get data from FORM
    $usuario = $_POST['usuario'];
    $clave = $_POST['clave'];

    if($usuario == '')
      $mensajeError = 'Ingresa usuario';
    if($clave == '')
      $mensajeError = 'Ingresa clave';

    if($mensajeError == '') {
      try {
        $sql = $conectar->prepare('SELECT p.*,u.* FROM personas p,usuarios u where u.dni=p.dni and u.usuario=:usuario');
        $sql->execute(array(':usuario' => $usuario));
 

        $data = $sql->fetch(PDO::FETCH_ASSOC);
        if($data == false){
          $mensajeError = "Usuario Incorrecto";
        }
        else {
          if($clave == $data['clave']) {
            $_SESSION['nombreCompleto'] = $data['nombres']." ".$data['aPaterno']." ".$data['aMaterno'];
            $_SESSION['usuario'] = $data['usuario'];
            $_SESSION['codigoUsuario'] = $data['codigoUsuario'];
            $_SESSION['dni'] = $data['dni'];
            $_SESSION['clave'] = $data['clave']; 
            header('Location: principal.php');
            exit;
          }
          else
            $mensajeError = 'Contraseña Invalida';
        }
      }
      catch(PDOException $e) {
        $mensajeError = $e->getMessage();
      }
    }
  }
?>


<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="imagenes/favicon.ico">

    <title>warehouse</title>

    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/usuarios.css" rel="stylesheet">
  </head>

  <body>
    <form class="form-signin"  action="" method="post">
      <div class="text-center mb-4">
         <?php
        if(isset($mensajeError)){
          echo '<h1 class="h3 mb-3 font-weight-normal style="color:#FF0000 !important;">'.$mensajeError.'</h1>';
        } else {
          echo '<h1 class="h3 mb-3 font-weight-normal">PROCOMPITE</h1>';
        }
      ?>
      </div>

  
    
      <div class="form-label-group">
        <input type="text" id="inputEmail" class="form-control"  placeholder="Usuario" name="usuario" value="<?php if(isset($_POST['usuario'])) echo $_POST['usuario'] ?>" required autofocus>
        <label for="inputEmail">Usuario</label>
      </div>

      <div class="form-label-group">
        <input type="clave" id="inputclave" class="form-control" placeholder="Clave" name="clave" alue="<?php if(isset($_POST['clave'])) echo $_POST['clave'] ?>"   required>
        <label for="inputclave">Clave</label>
      </div>

 
      <button class="btn btn-lg btn-primary btn-block" type="submit" name='login'>Ingresar</button>
 
    </form>
  </body>
</html>
