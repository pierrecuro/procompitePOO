<?php
require 'htmlCabeza.php';  


if(isset($_POST['Agregar'])) {
		$mensajeError = '';
		//$codigoMarca = $_POST['codigoMarca'];
		$marca = trim($_POST['marca']); 
		if($mensajeError == ''){ try {
		// print_r($_POST);
		$sql = $conectar->prepare('INSERT INTO marcas (marca) VALUES (:marca)');
		$sql->execute(array(':marca' => $marca));
		header('Location: marcasCRUD.php?action=1');
		exit;
		} catch(PDOException $e) {
		echo $e->getMessage();
		}} 
}


if(isset($_GET['eliminar'])) {
		$codigoMarca= $_GET['eliminar'];
		$sqlDelete = $conectar->prepare("DELETE FROM marcas WHERE codigoMarca = ?");
		$sqlDelete->execute([$codigoMarca]);
		$sqlDelete = null;
}


if(isset($_GET['editar'])) {
		echo $codigoMarca= $_GET['editar']; 
		$sqlEditar = $conectar->prepare("SELECT * FROM marcas WHERE codigoMarca= ?");
		$sqlEditar->execute([$codigoMarca]);
		$unRegistro = $sqlEditar->fetch(PDO::FETCH_LAZY);
		if(!$unRegistro) exit('no hay registros');
		/*similares muestras de registros echo $unRegistro[0];echo $unRegistro->producto; echo $unRegistro['producto'];*/
		$sqlEditar = null;
}

 
if(isset($_POST['Modificar'])) {
		$codigoMarca= $_POST['codigoMarca'];
		$marca = trim($_POST['marca']); 
		$sqlModificar = $conectar->prepare("UPDATE `marcas` SET  `marca` = '$marca'  WHERE `codigoMarca` = $codigoMarca");
		$sqlModificar->execute([$codigoMarca]);
		$sqlModificar = null;
		header('Location: marcasCRUD.php?action=2');
}

 
 
?> 
<div class="container">
  <h4 class="mb-3">UNIDAD DE marcas</h4>

<form action="" method="post"  > 
<div class="row">
                      <div class="col-md-10 mb-3">
                      <label for="country">marcas</label>
                      <input type="text" class="form-control" name="marca" placeholder="" 
                      value="<?php if(isset($_GET['editar'])) {  echo $unRegistro->marca; }?>" required style="text-transform:uppercase;" onkeyup="javascript:this.value=this.value.toUpperCase();">
                      </div>
 

<div class="col-md-3 mb-3">
<?php if(isset($_GET['editar'])) {?>
<input type="submit" name='Modificar' value="modicar" class="btn btn-primary btn-lg btn-block" /> 
<input type="hidden"  name="codigoMarca"  value="<?php if(isset($_GET['editar'])) {  echo $unRegistro->codigoMarca; }?>" > 
<?php  } else {  ?>
<input type="submit" name='Agregar' value="Agregar" class="btn btn-primary btn-lg btn-block" />
<?php  }?>
</div>
<div class="col-md-2 mb-2">
<a href="marcasCRUD.php" class="btn btn-primary btn-lg btn-block" style="background: #fff !important;color: #000 !important;" />Nuevo</a>
</div>

  </div> 
</form>

<!---INICIO LISTADO---->
<h2>unidad de marcas</h2>
          <div class="table-responsive">
            <table class="table table-striped table-sm">
              <thead>
                <tr  align="">
                  <th>N°</th>
                  <th>codigoMarca</th>
                  <th>marca</th> 
                  <th> </th>  
                </tr>
              </thead>
              <tbody>                 
					<?php
					$i=1;
					$sqlPDO = $conectar->prepare("SELECT * FROM `marcas` ORDER BY codigoMarca DESC");
					$sqlPDO->execute(array(':codigoMarca' => 0));
					$lista = $sqlPDO->fetchAll(PDO::FETCH_ASSOC);
					foreach($lista as $obj){ 
					echo  "<tr><td>".$i."</td><td>".$obj['codigoMarca']."</td><td>".$obj['marca']."</td><td><a href=?editar=".$obj['codigoMarca'].">Editar</a></td>  </tr>"; 
 
					 $i++;
					}?>
              </tbody>
            </table>
          </div> 
<!---FIN LISTADO---->


</div>        
 
<?php
  require 'htmlPie.php'; 
?>