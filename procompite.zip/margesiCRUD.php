<?php
require 'htmlCabeza.php';  


if(isset($_POST['Agregar'])) { 

		$margesi = trim($_POST['margesi']); 
 
		$tipo = $_POST['tipo']; 
		if($mensajeError == ''){ try {
		// print_r($_POST);
		$sql = $conectar->prepare('INSERT INTO margesi (margesi,tipo) VALUES ( :margesi,:tipo)');
		$sql->execute(array(':margesi' => $margesi,':tipo' => $tipo));
		header('Location: margesiCRUD.php?action=1');
		exit;
		} catch(PDOException $e) {
		echo $e->getMessage();
		}} 
}


if(isset($_GET['eliminar'])) {
		$codigoMargesi= $_GET['eliminar'];
		$sqlDelete = $conectar->prepare("DELETE FROM margesi WHERE codigoMargesi = ?");
		$sqlDelete->execute([$codigoMargesi]);
		$sqlDelete = null;
}


if(isset($_GET['editar'])) {
		$codigoMargesi= $_GET['editar']; 
		$sqlSelect = $conectar->prepare("SELECT * FROM `margesi` WHERE `codigoMargesi`= ?");
		$sqlSelect->execute([$codigoMargesi]);
		$unRegistro = $sqlSelect->fetch(PDO::FETCH_LAZY);
		if(!$unRegistro) exit('no hay registros');
		/*similares muestras de registros echo $unRegistro[0];echo $unRegistro->producto; echo $unRegistro['producto'];*/
		$sqlSelect = null;
}

 
if(isset($_POST['Modificar'])) {
		$codigoMargesi= $_POST['codigoMargesi'];
		$margesi = trim($_POST['margesi']); 
		$tipo = $_POST['tipo']; 
		$sqlModificar = $conectar->prepare("UPDATE `margesi` SET `margesi` = '$margesi', `tipo` = '$tipo' WHERE `codigoMargesi` = $codigoMargesi");
		$sqlModificar->execute([$codigoMargesi]);
		$sqlModificar = null;
		header('Location: margesiCRUD.php?action=2');
}
 

 
?> 
<div class="container">
  <h4 class="mb-3">margesi</h4>

<form action="" method="post"  > 
<div class="row">
                      <div class="col-md-5 mb-3">
                      <label for="country">margesi</label>
                      <input type="text" class="form-control" name="margesi" placeholder="" 
                      value="<?php if(isset($_GET['editar'])) {  echo $unRegistro->margesi; }?>" required style="text-transform:uppercase;" onkeyup="javascript:this.value=this.value.toUpperCase();">
                      </div>

                       <div class="col-md-5 mb-3">
                      <label for="country">tipo</label>
                      <input type="text" class="form-control" name="tipo" placeholder="" 
                      value="<?php if(isset($_GET['editar'])) {  echo $unRegistro->tipo; }?>" required style="text-transform:uppercase;" onkeyup="javascript:this.value=this.value.toUpperCase();">
                      </div>
 



<div class="col-md-3 mb-3">
<?php if(isset($_GET['editar'])) {?>
<input type="submit" name='Modificar' value="modicar" class="btn btn-primary btn-lg btn-block" /> 
<input type="hidden"  name="codigoMargesi"  value="<?php if(isset($_GET['editar'])) {  echo $unRegistro->codigoMargesi; }?>" > 
<?php  } else {  ?>
<input type="submit" name='Agregar' value="Agregar" class="btn btn-primary btn-lg btn-block" />
<?php  }?>
</div>
<div class="col-md-2 mb-2">
<a href="margesiCRUD.php" class="btn btn-primary btn-lg btn-block" style="background: #fff !important;color: #000 !important;" />Nuevo</a>
</div>

  </div> 
</form>

<!---INICIO LISTADO---->
<h2>PRODUCTOS</h2>
          <div class="table-responsive">
            <table class="table table-striped table-sm">
              <thead>
                <tr  align="">
                  <th>N°</th> 
                  <th>margesi</th>
                  <th>tipo</th>   
                  <th> </th>  
                </tr>
              </thead>
              <tbody>                 
					<?php 	  

					$i=1;
					$sqlPDO = $conectar->prepare("SELECT * FROM `margesi` ORDER BY tipo ASC");
					$sqlPDO->execute(array(':codigoMargesi' => 0));
					$lista = $sqlPDO->fetchAll(PDO::FETCH_ASSOC);
					foreach($lista as $obj){ 
					echo  "<tr><td>".$i."</td><td>".$obj['margesi']."</td><td>".$obj['tipo']."</td> <td>
					 <a href=?editar=".$obj['codigoMargesi'].">Editar</a></td>  </tr>";  $i++;
					}?>
              </tbody>
            </table>
          </div> 
<!---FIN LISTADO---->


</div>        
 
<?php
  require 'htmlPie.php'; 
?>