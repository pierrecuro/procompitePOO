<?php
require 'htmlCabeza.php';  


if(isset($_POST['Agregar'])) {
		$mensajeError = '';
		//$codigoMedida = $_POST['codigoMedida'];
		$unidadMedida = trim($_POST['unidadMedida']); 
		if($mensajeError == ''){ try {
		// print_r($_POST);
		$sql = $conectar->prepare('INSERT INTO medidas (unidadMedida) VALUES (:unidadMedida)');
		$sql->execute(array(':unidadMedida' => $unidadMedida));
		header('Location: medidasCRUD.php?action=1');
		exit;
		} catch(PDOException $e) {
		echo $e->getMessage();
		}} 
}


if(isset($_GET['eliminar'])) {
		$codigoMedida= $_GET['eliminar'];
		$sqlDelete = $conectar->prepare("DELETE FROM medidas WHERE codigoMedida = ?");
		$sqlDelete->execute([$codigoMedida]);
		$sqlDelete = null;
}


if(isset($_GET['editar'])) {
		echo $codigoMedida= $_GET['editar']; 
		$sqlEditar = $conectar->prepare("SELECT * FROM medidas WHERE codigoMedida= ?");
		$sqlEditar->execute([$codigoMedida]);
		$unRegistro = $sqlEditar->fetch(PDO::FETCH_LAZY);
		if(!$unRegistro) exit('no hay registros');
		/*similares muestras de registros echo $unRegistro[0];echo $unRegistro->producto; echo $unRegistro['producto'];*/
		$sqlEditar = null;
}

 
if(isset($_POST['Modificar'])) {
		$codigoMedida= $_POST['codigoMedida'];
		$unidadMedida = trim($_POST['unidadMedida']); 
		$sqlModificar = $conectar->prepare("UPDATE `medidas` SET  `unidadMedida` = '$unidadMedida'  WHERE `codigoMedida` = $codigoMedida");
		$sqlModificar->execute([$codigoMedida]);
		$sqlModificar = null;
		header('Location: medidasCRUD.php?action=2');
}

 
 
?> 
<div class="container">
  <h4 class="mb-3">UNIDAD DE MEDIDAS</h4>

<form action="" method="post"  > 
<div class="row">
                      <div class="col-md-10 mb-3">
                      <label for="country">Medidas</label>
                      <input type="text" class="form-control" name="unidadMedida" placeholder="" 
                      value="<?php if(isset($_GET['editar'])) {  echo $unRegistro->unidadMedida; }?>" required style="text-transform:uppercase;" onkeyup="javascript:this.value=this.value.toUpperCase();">
                      </div>
 

<div class="col-md-3 mb-3">
<?php if(isset($_GET['editar'])) {?>
<input type="submit" name='Modificar' value="modicar" class="btn btn-primary btn-lg btn-block" /> 
<input type="hidden"  name="codigoMedida"  value="<?php if(isset($_GET['editar'])) {  echo $unRegistro->codigoMedida; }?>" > 
<?php  } else {  ?>
<input type="submit" name='Agregar' value="Agregar" class="btn btn-primary btn-lg btn-block" />
<?php  }?>
</div>
<div class="col-md-2 mb-2">
<a href="medidasCRUD.php" class="btn btn-primary btn-lg btn-block" style="background: #fff !important;color: #000 !important;" />Nuevo</a>
</div>

  </div> 
</form>

<!---INICIO LISTADO---->
<h2>unidad de Medidas</h2>
          <div class="table-responsive">
            <table class="table table-striped table-sm">
              <thead>
                <tr  align="">
                  <th>N°</th>
                  <th>codigoMedida</th>
                  <th>unidadMedida</th> 
                  <th> </th>  
                </tr>
              </thead>
              <tbody>                 
					<?php
					$i=1;
					$sqlPDO = $conectar->prepare("SELECT * FROM `medidas` ORDER BY codigoMedida DESC");
					$sqlPDO->execute(array(':codigoMedida' => 0));
					$lista = $sqlPDO->fetchAll(PDO::FETCH_ASSOC);
					foreach($lista as $obj){ 
					echo  "<tr><td>".$i."</td><td>".$obj['codigoMedida']."</td><td>".$obj['unidadMedida']."</td><td><a href=?editar=".$obj['codigoMedida'].">Editar</a></td>  </tr>"; 
/*
echo  "<tr><td>".$i."</td><td>".$obj['codigoMedida']."</td><td>".$obj['unidadMedida']."</td><td>
					<a href=?eliminar=".$obj['codigoMedida'].">Eliminar</a><br><a href=?editar=".$obj['codigoMedida'].">Editar</a></td>  </tr>"; 
*/
					 $i++;
					}?>
              </tbody>
            </table>
          </div> 
<!---FIN LISTADO---->


</div>        
 
<?php
  require 'htmlPie.php'; 
?>