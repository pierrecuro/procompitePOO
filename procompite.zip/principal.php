<?php
  require 'htmlCabeza.php'; 
?>
<div class="container">
<div class="row">
	<div class="col-md-8 order-md-1">
	  <h4 class="mb-3">Bienvenido <?php echo $_SESSION['nombreCompleto']; ?></h4>
	</div>
</div>
</div>
<?php
  require 'htmlPie.php'; 
?>