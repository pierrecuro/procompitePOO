<?php
include('config.php');
/*
$stmt=$db_con->prepare('select * from books');
$stmt->execute();
*/
//$cu='2158880';

  $cu = $_GET['cu'];
$stmt=$conectar->prepare("SELECT  m.margesi, p.dni,p.aPaterno,p.aMaterno,p.nombres,so.nombreProyecto from margesi m,datos d,socios s, entregas e, articulos a,personas p,asociaciones so where e.codigoUnificado='$cu' and e.codigoEntrega=d.codigoEntrega and a.codigoArticulo=e.codigoArticulo and p.dni=d.dni and p.dni=s.dni and so.codigoUnificado=d.codigoUnificado and m.codigoMargesi=s.codigoMargesi group by p.dni");
$stmt->execute();

/*
2158929

SELECT   @rownum:=@rownum+1 AS Nro,p.dni,s.condicion,p.aPaterno,p.aMaterno,p.nombres,so.nombreProyecto from (SELECT @rownum:=0) num,datos d,socios s, entregas e, articulos a,personas p,asociaciones so where e.codigoUnificado='2158929' and e.codigoEntrega=d.codigoEntrega and a.codigoArticulo=e.codigoArticulo and p.dni=d.dni and p.dni=s.dni and so.codigoUnificado=d.codigoUnificado
group by p.dni

 
SELECT e.codigoEntrega,a.articulo,m.unidadMedida,d.marca,m.unidadMedida FROM entregas e, articulos a, medidas m, marcas d WHERE e.codigoUnificado='2158929' and e.codigoArticulo=a.codigoArticulo and e.codigoMedida=m.codigoMedida and d.codigoMarca= e.codigoMarca

*/

 

$gsent = $conectar->prepare("SELECT * FROM asociaciones where codigoUnificado='$cu'");
$gsent->execute();
$result = $gsent->fetch(PDO::FETCH_OBJ);

$nRows = $conectar->prepare("SELECT count(*)  FROM entregas WHERE codigoUnificado='$cu'")->fetchColumn(); 
echo $nRows;

 
$nRows =$conectar->prepare("SELECT count(*)  FROM entregas WHERE codigoUnificado='$cu'"); 
$nRows->execute(); 
$numeroRows = $nRows->fetchColumn()+6; 

 
/*
$sql=$conectar->prepare("SELECT e.codigoEntrega,a.articulo,m.unidadMedida,d.marca,m.unidadMedida FROM entregas e, articulos a, medidas m, marcas d WHERE e.codigoUnificado='$cu' and e.codigoArticulo=a.codigoArticulo and e.codigoMedida=m.codigoMedida and d.codigoMarca= e.codigoMarca");
$sql->execute();
*/

$sql = $conectar->prepare("SELECT e.codigoEntrega,a.articulo,m.unidadMedida,d.marca,m.unidadMedida FROM entregas e, articulos a, medidas m, marcas d WHERE e.codigoUnificado='$cu' and e.codigoArticulo=a.codigoArticulo and e.codigoMedida=m.codigoMedida and d.codigoMarca= e.codigoMarca");
$sql->execute(array());
$listaMarcaArticulo = $sql->fetchAll(PDO::FETCH_ASSOC);


/*
 $sqlMedidas=$conectar->prepare("SELECT e.codigoEntrega,a.articulo,m.unidadMedida,d.marca,m.unidadMedida FROM entregas e, articulos a, medidas m, marcas d WHERE e.codigoUnificado='$cu' and e.codigoArticulo=a.codigoArticulo and e.codigoMedida=m.codigoMedida and d.codigoMarca= e.codigoMarca");
$sqlMedidas->execute();
 */

//echo intval($nroTotal, 6);
$i=1;
?>

<!DOCTYPE html>
<html lang="en">

 <meta http-equiv="content-type" content="text/html;charset=utf-8" /> 
<head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <link href='css/reportes.css' type='text/css' rel='stylesheet' >
  <script src="js/tableToExcel.js"></script> 
</head>
<body>

  <input type="button" onclick="tableToExcel('testTable', 'consolidado')" value="Export to Excel">

<div class="container">
  <div class="panel">
    <div class="panel-heading"> 
      <div class="panel-body">

 <?php 
       
   
//echo "<b>codigo Unificado :</b>".$cu;
?>  

         <table border="1" id="testTable" class="table table-bordered table-striped">
            <tr>
              <td colspan="<?php echo $numeroRows;?>"><b>MUNICIPALIDAD DISTRITAL DE ECHARATI</b></td>
            </tr>
            <tr>
              <td colspan="<?php echo $numeroRows;?>" width='900'><?php echo "<b>nombre Proyecto : ".$result->nombreProyecto;?></td>
            </tr>
            <tr>
              <td colspan="<?php echo $numeroRows;?>" width='900'><?php echo "<b>nombre Corto :</b><b style='color:red;'> ".$result->sector." ".$result->cadenaProductiva."</b>";?> -  <?php echo "codigo Unificado : <b style='color:green;'>".$result->codigoUnificado."</b> ";?></td>
            </tr>
            <tr>
              <td colspan="<?php echo $numeroRows;?>" width='900'><?php echo "<b>Convocatoria : #</b>".$result->convocatoria;?></td>
            </tr>
            <tr>
              <td colspan="<?php echo $numeroRows;?>" width='900'><?php echo "<b>Resolución : </b>".$result->resolucion;  echo "<b> fecha Resolución : </b>".$result->fechaResolucion;  ?></td>
            </tr>
            <tr>
              <td ></td>
            </tr>
            
          
            
            <tr>
              <td colspan="6"></td>
                <?php
                foreach($listaMarcaArticulo as $obj){ 
                echo '<td>&nbsp; '.$obj['unidadMedida'].' </td> ';
                }
                ?>
            </tr>
          
            <tr>
              
              <th>Nro.</th>
              <th>DNI</th>
              <th>condicion</th>
              <th>aPaterno</th>
              <th>aMaterno</th>
              <th>nombres</th> 
                <?php
                foreach($listaMarcaArticulo as $obj){ 
                echo '<th>&nbsp;<div class=rotar>'.$obj['articulo'].'</div></th> ';
                }
                
                ?>
            </tr>



    			<?php
    
          while($row=$stmt->FETCH(PDO::FETCH_ASSOC)){
            $dni=$row["dni"];
            echo '
            <tr>
              <td>'.$i++.'</td>
              <td>'.$row["dni"].'</td>
              <td>'.$row["margesi"].'</td>
              <td>'.$row["aPaterno"].'</td>
              <td>'.$row["aMaterno"].'</td>
              <td>'.$row["nombres"].'</td>
            ';


              $sqlColumna=$conectar->prepare("SELECT d.cantidad  FROM  datos d,entregas e  WHERE d.codigoUnificado='$cu' and d.dni='$dni' and e.codigoEntrega=d.codigoEntrega");
              $sqlColumna->execute();
                
              while($rowc=$sqlColumna->FETCH(PDO::FETCH_ASSOC)){
              echo '<td>'.$rowc["cantidad"].'</td>'; 
             
              }

          echo '</tr>';

          }

 

 echo '<tr><td colspan=6 class=derecha >TOTAL:</td>';


$sqlTotal=$conectar->prepare("SELECT  COUNT(*) total_repetidos, sum(cantidad) as subTotal, codigoEntrega 
FROM datos WHERE codigoUnificado='$cu'
GROUP By codigoEntrega 
HAVING total_repetidos > 1");
$sqlTotal->execute();

while($rowt=$sqlTotal->FETCH(PDO::FETCH_ASSOC)){
echo '<td>'.$rowt["subTotal"].'</td>';
}

echo '</tr>';



    			?>
    		</table> 

      </div>

    </div>

  </div>

</div>



</body>
</html>
