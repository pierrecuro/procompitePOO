<?php
require 'htmlCabeza.php';  


if(isset($_POST['Agregar'])) {
		$mensajeError = '';
		$dni = trim($_POST['dni']); 
		$aPaterno = trim($_POST['aPaterno']); 
		$aMaterno = trim($_POST['aMaterno']); 
		$nombres = trim($_POST['nombres']); 
		$fechaNacimiento = trim($_POST['fechaNacimiento']); 
		$sexo = trim($_POST['sexo']); 
		$categoria = trim($_POST['categoria']); 
		$celular = trim($_POST['celular']); 
		$correo = trim($_POST['correo']);  
		$observaciones = trim($_POST['observaciones']);  
		/**/
		if($mensajeError == ''){ try {
			// print_r($_POST);
	 		$sql = $conectar->prepare('INSERT INTO personas (dni, aPaterno, aMaterno, nombres, fechaNacimiento, sexo, categoria, celular, correo, observaciones) VALUES (:dni,:aPaterno,:aMaterno,:nombres,:fechaNacimiento,:sexo,:categoria,:celular,:correo,:observaciones)');
			
			$sql->execute(array(':dni' => $dni,':aPaterno' => $aPaterno,':aMaterno' => $aMaterno,':nombres' => $nombres,':fechaNacimiento' => $fechaNacimiento,':sexo' => $sexo,':categoria' => $categoria,':celular' => $celular,':correo' => $correo,':observaciones' => $observaciones));

			header('Location: personasCRUD.php?action=1');
			exit;
			} catch(PDOException $e) {	echo $e->getMessage();}
		} 
}


if(isset($_GET['eliminar'])) {
		$codigoPersonal= $_GET['eliminar'];
		$sqlDelete = $conectar->prepare("DELETE FROM personas WHERE codigoPersonal = ?");
		$sqlDelete->execute([$codigoPersonal]);
		$sqlDelete = null;
}


if(isset($_GET['editar'])) {
		echo $codigoPersonal= $_GET['editar']; 
		$sqlEditar = $conectar->prepare("SELECT * FROM personas WHERE codigoPersonal= ?");
		$sqlEditar->execute([$codigoPersonal]);
		$unRegistro = $sqlEditar->fetch(PDO::FETCH_LAZY);
		if(!$unRegistro) exit('no hay registros');
		/*similares muestras de registros echo $unRegistro[0];echo $unRegistro->producto; echo $unRegistro['producto'];*/
		$sqlEditar = null;
}

 
if(isset($_POST['Modificar'])) {
		$codigoPersonal= $_POST['codigoPersonal'];
		$dni = trim($_POST['dni']); 
		$aPaterno = trim($_POST['aPaterno']); 
		$aMaterno = trim($_POST['aMaterno']); 
		$nombres = trim($_POST['nombres']); 
		$fechaNacimiento = trim($_POST['fechaNacimiento']); 
		$sexo = trim($_POST['sexo']); 
		$categoria = trim($_POST['categoria']); 
		$celular = trim($_POST['celular']); 
		$correo = trim($_POST['correo']);  
		$observaciones = trim($_POST['observaciones']); 
		
		$sqlModificar = $conectar->prepare("UPDATE personas SET dni = '$dni',aPaterno = '$aPaterno',aMaterno = '$aMaterno',nombres = '$nombres',fechaNacimiento = '$fechaNacimiento',sexo = '$sexo',categoria = '$categoria',celular = '$celular',correo = '$correo',observaciones = '$observaciones' WHERE `codigoPersonal` = $codigoPersonal");
		$sqlModificar->execute([$codigoPersonal]);
		$sqlModificar = null;
		header('Location: personasCRUD.php?action=2');
}

 
 
?> 
<div class="container">
  <h4 class="mb-3">REPORTE	</h4>

<?php /*
<form action="" method="post"  > 
<div class="row">

<div class="col-md-2 mb-2">
<label for="country">DNI</label>
<input type="text" class="form-control" name="dni" placeholder="" 
value="<?php if(isset($_GET['editar'])) {  echo $unRegistro->dni; }?>" required style="text-transform:uppercase;" onkeyup="javascript:this.value=this.value.toUpperCase();">
</div>




<div class="col-md-3 mb-3">
<label for="country">aPaterno</label>
<input type="text" class="form-control" name="aPaterno" placeholder="" 
value="<?php if(isset($_GET['editar'])) {  echo $unRegistro->aPaterno; }?>" required style="text-transform:uppercase;" onkeyup="javascript:this.value=this.value.toUpperCase();">
</div>

<div class="col-md-3 mb-3">
<label for="country">aMaterno</label>
<input type="text" class="form-control" name="aMaterno" placeholder="" 
value="<?php if(isset($_GET['editar'])) {  echo $unRegistro->aMaterno; }?>" required style="text-transform:uppercase;" onkeyup="javascript:this.value=this.value.toUpperCase();">
</div>

<div class="col-md-3 mb-3">
<label for="country">nombres</label>
<input type="text" class="form-control" name="nombres" placeholder="" 
value="<?php if(isset($_GET['editar'])) {  echo $unRegistro->nombres; }?>" required style="text-transform:uppercase;" onkeyup="javascript:this.value=this.value.toUpperCase();">
</div>

<div class="col-md-3 mb-3">
<label for="country">fechaNacimiento</label>
<input type="text" class="form-control" name="fechaNacimiento" placeholder="" 
value="<?php if(isset($_GET['editar'])) {  echo $unRegistro->fechaNacimiento; }?>" required style="text-transform:uppercase;" onkeyup="javascript:this.value=this.value.toUpperCase();">
</div>

<div class="col-md-1 mb-1">
<label for="country">sexo</label>
<input type="text" class="form-control" name="sexo" placeholder="" 
value="<?php if(isset($_GET['editar'])) {  echo $unRegistro->sexo; }?>" required style="text-transform:uppercase;" onkeyup="javascript:this.value=this.value.toUpperCase();">
</div>



<div class="col-md-3 mb-3">
<label for="country">categoria</label>
<input type="text" class="form-control" name="categoria" placeholder="" 
value="<?php if(isset($_GET['editar'])) {  echo $unRegistro->categoria; }?>" required style="text-transform:uppercase;" onkeyup="javascript:this.value=this.value.toUpperCase();">
</div>

<div class="col-md-3 mb-3">
<label for="country">celular</label>
<input type="text" class="form-control" name="celular" placeholder="" 
value="<?php if(isset($_GET['editar'])) {  echo $unRegistro->celular; }?>" required style="text-transform:uppercase;" onkeyup="javascript:this.value=this.value.toUpperCase();">
</div>

<div class="col-md-4 mb-4">
<label for="country">correo</label>
<input type="email" class="form-control" name="correo" placeholder="" strtolower	
value="<?php if(isset($_GET['editar'])) {  echo $unRegistro->correo; }?>"  style="text-transform:lowercase;" onkeyup="javascript:this.value=this.value.toLowerCase();">
</div>
<div class="col-md-6 mb-5">
<label for="country">observaciones</label>
<input type="text" class="form-control" name="observaciones" placeholder="" 
value="<?php if(isset($_GET['editar'])) {  echo $unRegistro->observaciones; }?>"   style="text-transform:uppercase;" onkeyup="javascript:this.value=this.value.toUpperCase();">
</div>




<div class="col-md-3 mb-3">
<?php if(isset($_GET['editar'])) {?>
<input type="submit" name='Modificar' value="modicar" class="btn btn-primary btn-lg btn-block" /> 
<input type="hidden"  name="codigoPersonal"  value="<?php if(isset($_GET['editar'])) {  echo $unRegistro->codigoPersonal; }?>" > 
<?php  } else {  ?>
<input type="submit" name='Agregar' value="Agregar" class="btn btn-primary btn-lg btn-block" />
<?php  }?>
</div>
<div class="col-md-2 mb-2">
<a href="personasCRUD.php" class="btn btn-primary btn-lg btn-block" style="background: #fff !important;color: #000 !important;" />Nuevo</a>
</div>

  </div> 
</form>
*/?>

<!---INICIO LISTADO---->
<h2>Listado Personas</h2>
          <div class="table-responsive">
            <table class="table table-striped table-sm">
              <thead>
                <tr  align="">
                  <th>N°</th> 
                  <th>dni</th>  
                  <th>aPaterno</th>  
                  <th>aMaterno</th>  
                  <th>nombres</th>  
                  <th>fechaNacimiento</th>  
                  <th>sexo</th>  
                  <th>categoria</th>   
                  <th> </th>   
                </tr>
              </thead>
              <tbody>                 
					<?php 
					$i=1;
					$sqlPDO = $conectar->prepare("SELECT * FROM personas ORDER BY codigoPersonal DESC");
					$sqlPDO->execute(array(':codigoPersonal' => 0));
					$lista = $sqlPDO->fetchAll(PDO::FETCH_ASSOC);
					foreach($lista as $obj){ 
					echo  "<tr><td>".$i."</td><td>".$obj['dni']."</td><td>".$obj['aPaterno']."</td><td>".$obj['aMaterno']."</td><td>".$obj['nombres']."</td><td>".$obj['fechaNacimiento']."</td><td>".$obj['sexo']."</td><td>".$obj['categoria']."</td><td>".$obj['celular']."</td> <td><br></td></tr>"; 
 
 //<a href=?editar=".$obj['codigoPersonal'].">Editar</a>
					 $i++;
					}?>
              </tbody>
            </table>
          </div> 
<!---FIN LISTADO---->


</div>        
 
<?php
  require 'htmlPie.php'; 
?>