<?php
require 'htmlCabeza.php'; 


 //print_r($_POST);

$variable=0;
 
if(isset($_POST['nroIngreso'])) {
  $nroIngreso=$_POST['nroIngreso'];
}else{

  $nroIngreso=0;
}


if(isset($_POST['Agregar'])) {
		$mensajeError = ''; 
		$codigoSocio='';
		$nroIngreso = $_POST['nroIngreso'];
		$dni = $_POST['dni'];
		$cargo = $_POST['cargo'];
		$condicion = $_POST['condicion'];

		$codigoUnificado = trim($_POST['codigoUnificado']);
		$observaciones = date("d-m-Y");                           // 20010310
			 $i=0; 

			 while ($nroIngreso>$i) {
					$var_dni=trim($dni[$i]);   
					$var_cargo=trim($cargo[$i]);
					$var_condicion=trim($condicion[$i]); 


					$sqlcu=$conectar->prepare("SELECT dni,count(*) as valido  FROM `personas` WHERE `dni`='$var_dni'");
					$sqlcu->execute();
					$registros = $sqlcu->fetch(PDO::FETCH_OBJ);
					$registros->valido;

					if($registros->valido=='1'){
						//$dniRegistro[$k]=$registros->dni; 
						$sql=$conectar->prepare("SELECT  count(*) as socioExiste  FROM `socios` WHERE `dni`='$var_dni' and codigoUnificado='$codigoUnificado'");
						$sql->execute();
						$row = $sql->fetch(PDO::FETCH_OBJ);
						// si existe 1 =echo "dd:".$row->socioExiste;

						if($row->socioExiste=='0'){
							$sqlInsert = $conectar->prepare('INSERT INTO socios (codigoSocio,dni, cargo, condicion,   codigoUnificado, observaciones) VALUES (:codigoSocio,:dni,:cargo,:condicion, :codigoUnificado,:observaciones)');
							$sqlInsert->execute(array(':codigoSocio' => $codigoSocio,':dni' => $var_dni,':cargo' => $var_cargo,':condicion' => $var_condicion, ':codigoUnificado' => $codigoUnificado,':observaciones' => $observaciones));
							echo "<br>Fue ingresado correctamente el DNI:<b>".$var_dni."</b>"; 
						} 

					}
			 	$i++;
			 } 

 
}


 
if(isset($_GET['varCodigoUnificado'])  ) { 
    $codigoUnificado = trim($_GET['varCodigoUnificado']);


    $sql=$conectar->prepare("SELECT *,count(*) as total FROM `asociaciones` WHERE `codigoUnificado`=$codigoUnificado");
    $sql->execute();
    $registros = $sql->fetch(PDO::FETCH_OBJ);
    $totalR=$registros->total;

	$sqlUnico = $conectar->prepare("SELECT p.*,s.*, m.margesi FROM socios s,personas p,margesi m WHERE s.dni=p.dni and m.codigoMargesi=s.codigoMargesi and s.codigoUnificado=$codigoUnificado");

	$sqlUnico->execute(array());
	$lista = $sqlUnico->fetchAll(PDO::FETCH_ASSOC);
}
 

if(isset($_POST['eliminar'])) {
      $codigoSocio= trim($_POST['eliminar']);
    $sqlDelete = $conectar->prepare("DELETE FROM socios WHERE codigoSocio = ?");
    $sqlDelete->execute([$codigoSocio]);
    $sqlDelete = null;
    //echo "Fue eliminado correctamente";
}

$tablaMargesiActivo = $conectar->prepare("SELECT * FROM `margesi` WHERE `tipo`='CONDICION' ORDER BY  `codigoMargesi` DESC");
$tablaMargesiActivo->execute(array());
$listaTabla = $tablaMargesiActivo->fetchAll(PDO::FETCH_ASSOC);

?>


 



<div class="container">

 
<?php
switch ($variable) {
case 1:
?>    
    <div class="row"> 
          <div class="col-md-3 order-md-3" style="padding: 25px 0 0 0;">
              <center>  
                 <a href="reporteGenerador.php?cu=<?php echo $codigoUnificado;?>" target='_blank'  class="btn btn-primary btn-lg btn-block">Reporte Excel </a>
              </center> 
          </div>
    </div>
<?php
break;
case 0:
?>    

<div class="row">
      <div class="col-md-8 order-md-8">  
        <h4 class="mb-3"> CODIGO UNIFICADO PARA AGREGAR SOCIOS : </h4>
        <form   method="Get" class="needs-validation" novalidate> 
              <div class="col-md-6 mb-6">
                    <div class="input-group">
                      <div class="input-group-prepend"><span class="input-group-text">CODIGO UNIFICADO</span></div>
                      <input class="form-control" value="" type="number" id="CU" name='varCodigoUnificado' placeholder="Antes Código SIAF" required min="1" pattern="[0-9]+" onpaste="return true;" onDrop="return false;" autocomplete=off>

                    </div>  
              </div>
              <div class="col-md-3 mb-3">
                    <div class="input-group"> 
                    <input type="submit" name='buscar' value="Buscar" class="btn btn-primary btn-lg btn-block" /> 
                    <a href='sociosCRUD.php'" class="btn btn-primary btn-lg btn-block">nuevo</a>
                    </div>
              </div>
              
      </form>
      </div>
</div>




<?php
//inicio
if(isset($_GET['varCodigoUnificado'])  ) {
if($totalR>0) {
?>
 <b>nombre Proyecto:</b><?php      
  echo "<br>".$registros->nombreProyecto."<br>";
  echo "<b>nombre Corto : ".$registros->sector." ".$registros->cadenaProductiva."</b> - ".$registros->tipoAsociacion."<br>"; 
  echo "<b>Convocatoria : #</b>".$registros->convocatoria."<br>";
  echo "<b>fecha Resolución : </b>".$registros->fechaResolucion."<br>";
  echo "<b>Resolución : </b>".$registros->resolucion."<br>";
  echo "<h3>codigo Unificado : ".$codigoUnificado."</h3>";
  echo "<b>cierreActa : ".$registros->cierreActa."</b>";
?>   
   
      <div class="panel-body">


       
        <table border="1" class="table table-bordered table-striped">
            <tr>
              <th>N°</th> 
              <th>dni</th>
              <th>aPaterno</th> 
              <th>aMaterno</th>  
              <th>nombres</th>   
              <th>condición</th>   
              <th>cargo</th>   
              <th> </th>   
            </tr> 

          <?php
          $c=1;  
          foreach($lista as $obj){ 
          echo '
          <tr>
          <td>'.$c.'</td> 
          <td>'.$obj["dni"].'</td>
          <td>'.$obj["aPaterno"].'</td>  
          <td>'.$obj["aMaterno"].'</td>  
          <td>'.$obj["nombres"].'</td>   
          <td>'.$obj["margesi"].'</td>   
          <td>'.$obj["cargo"].'</td>  
          <td>';
          if($registros->cierreActa!='SI'){
          echo '<form   method="POST" action=""  > 
          <input   type="hidden"    name="eliminar" value="'.$obj["codigoSocio"].'" >
          <input   type="hidden"    name="codigoUnificado" value="'.$obj["codigoUnificado"].'" >
          <input type="submit" name="eliminarRegistro" value="Eliminar" class="btn btn-primary btn-lg btn-block" />
          </form>';
          }

          echo '</td> </tr>';





          $c++;} 
          ?>
        </table>
      </div> 

 
<?php
//inicio
if(isset($_GET['varCodigoUnificado']) AND $registros->cierreActa!='SI'  ) {
if($totalR>0) {
?> 

<div class="row">
      <div class="col-md-8 order-md-8">  
 

        <h4 class="mb-3">  NUMERO DE BENEFICIARIOS EN : "<?php  echo  $registros->sector." ".$registros->cadenaProductiva; ?> ":</h4>
        <form   method="POST" class="needs-validation" novalidate> 
              <div class="col-md-6 mb-6">
                    <div class="input-group">
                      <div class="input-group-prepend"><span class="input-group-text">INGRESO NRO DE ASOCIADOS</span></div>
                      <input class="form-control" type="number" autofocus  name='nroIngreso' placeholder="CANTIDAD"   min="1" pattern="[0-9]+" onpaste="return true;" onDrop="return false;" autocomplete=off>
                    </div>  
              </div>
              <div class="col-md-3 mb-3">
                    <div class="input-group"> 
                    <input type="submit" name='INGRESAR' value="INGRESAR" class="btn btn-primary btn-lg btn-block" />
                    </div>
              </div>
 


      </form>
              
              
      <div class="panel-body">

      <form   method="POST"   class="needs-validation" >
        <table border="1" class="table table-bordered table-striped">
            <tr>
 
              <th>N°</th> 
              <th>dni</th>
              <th >cargo</th> 
              <th>condición</th>  
              <th>codigo Unificado</th>   
            </tr>

          <?php
		$k=0; 
		$i=1;
          while($nroIngreso>$k){  
          echo '
          <tr>
          <td>'.$i.'</td> 
          <td><input  type="number" name="dni[]"  required min="1" pattern="[0-9]+" onpaste="return true;" onDrop="return false;" /></td>
          <td><input  type="text"  name="cargo[]"   /></td> ';
          ?>



          <td>  
              <select class="custom-select d-block w-100"  name="condicion[]"   required="">
              <?php
              $c=1;  
              foreach($listaTabla as $objeto){ 
              ?>
              <option value="<?php echo $objeto['codigoMargesi'];?>" > <?php echo $objeto['margesi']; ?></option>
              <?php }   ?>
              </select> 
          </td>  
          <?php
          echo  '<td>'.$codigoUnificado.'</td>  
          </tr>';
          $k++;$i++;} 
          ?>
        </table>
      </div> 


              <div class="col-md-3 mb-3">
                    <div class="input-group">  
            						<input type="hidden"  name="codigoSocio"    > 
            						<input type="hidden" name='nroIngreso' value="<?php echo $nroIngreso;?>"   /> 
            						<input type="hidden" name='codigoUnificado' value="<?php echo $codigoUnificado;?>"   /> 
            						<input type="submit" name='Agregar' value="Agregar" class="btn btn-primary btn-lg btn-block" />  
                    </div>
              </div>
   

              
      </form>
      </div>


</div>

<?php } }?>
 
<?php } else {echo "<div style='color:red; '>No esta registrado el Codigo unificado <b>".$codigoUnificado."</b> click para   <a href='asociacionesCRUD.php'>Agregar</a> nuevo codigo</div> ";}   } ?>
<?php
break;  }
?>     
          
</div> 
 




 
<?php
  require 'htmlPie.php'; 
?>