<?php
  require 'htmlCabeza.php'; 
 
  if(isset($_POST['register'])) {
    $mensajeError = '';

    // Get data from FROM
    $dni = $_POST['dni'];
    $usuario = $_POST['usuario'];
    $clave = $_POST['clave'];
    $pin = $_POST['clave'];
 
    if($usuario == '')
      $mensajeError = 'usuario';
    if($clave == '')
      $mensajeError = 'clave'; 

    if($mensajeError == ''){
      try {

        $sql = $conectar->prepare('INSERT INTO usuarios (dni, usuario, clave, pin) VALUES (:dni, :usuario, :clave, :clave)');
        $sql->execute(array(':dni' => $dni,':usuario' => $usuario,':clave' => $clave,':pin' => $pin));
        header('Location: usuarioAgregar.php?action=joined');
        exit;
      }
      catch(PDOException $e) {
        echo $e->getMessage();
      }
    }
  }
 
?>



    <div class="container">
 
      <div class="row">
       


        <div class="col-md-8 order-md-1">  
           <h4 class="mb-3">USUARIOS </h4>

      <form action="" method="post" class="needs-validation" novalidate> 
            <div class="mb-3"> 
              <div class="input-group">
                <div class="input-group-prepend">
                  <span class="input-group-text">DNI</span>
                </div>
                <input type="text" class="form-control" id="username" name='dni' placeholder="dni" required>
                <div class="invalid-feedback" style="width: 100%;">
                  DNI
                </div>
              </div>
            </div>

            <div class="row">
              <div class="col-md-6 mb-3">
                <label for="lastName">Usuario</label>
                <input type="text" class="form-control" id="lastName" name='usuario'  placeholder="usuario" value="" required>
                <div class="invalid-feedback">
                  Usuario
                </div>
              </div>
              <div class="col-md-6 mb-3">
                <label for="lastName">Clave</label>
                <input type="text" class="form-control" id="lastName"   name='clave'  placeholder="clave" value="" required>
                <div class="invalid-feedback">
                  Clave
                </div>
              </div>
            </div>
   
            <hr class="mb-4">
            <input type="submit" name='register' value="Agregar" class="btn btn-primary btn-lg btn-block" /> 
              
          </form>
        </div>
      </div>
<?php
  require 'htmlPie.php'; 
?>