<?php
  require 'htmlCabeza.php'; 
 
print_r($_POST);

  if(isset($_POST['register'])) {
    $mensajeError = '';

    // Get data from FROM
    $dni = $_POST['dni'];
    $usuario = $_POST['usuario'];
    $clave = $_POST['clave'];
    $pin = $_POST['clave'];
 
    if($usuario == '')
      $mensajeError = 'usuario';
    if($clave == '')
      $mensajeError = 'clave'; 

    if($mensajeError == ''){
      try {

        $sql = $conectar->prepare('INSERT INTO usuarios (dni, usuario, clave, pin) VALUES (:dni, :usuario, :clave, :clave)');
        $sql->execute(array(':dni' => $dni,':usuario' => $usuario,':clave' => $clave,':pin' => $pin));
        header('Location: usuarioAgregar.php?action=joined');
        exit;
      }
      catch(PDOException $e) {
        echo $e->getMessage();
      }
    }
  }
 

 



if(isset($_POST['Agregar'])) {
    $arrayMenu = $_POST['arrayMenu'];
    $dni = $_POST['dni'];
    $x=0;
    //echo "xx".count($arrayMenu);
    while ($x<count($arrayMenu)){       
      
     $codigoMenu=$arrayMenu[$x]; //."<br>:<br>";
      $sql = $conectar->prepare('INSERT INTO privilegios (codigoPrivilegio, codigoMenu,  dni) VALUES (codigoPrivilegio,:codigoMenu,:dni)');
      $sql->execute(array(':codigoMenu' => $codigoMenu,':dni' => $dni));
      $x++;
    } 

}




  if(isset($_POST['buscar'])) {
    
    $dni = $_POST['dni'];

      $mensajeError = 'dni';
    if($mensajeError == ''){
      try {

//SELECT * FROM `menus` ORDER BY `menus`.`indice` ASC


        $sql = $conectar->prepare('SELECT * FROM `menus` WHERE dni=$dni');
        $sql->execute(array(':dni' => $dni));
     //   header('Location: usuarioAgregar.php?action=joined');
        exit;
      }
      catch(PDOException $e) {
        echo $e->getMessage();
      }
    }
  }
 
?>



    <div class="container">
 
      <div class="row"> 
            <div class="col-md-8 order-md-1">  
            <h4 class="mb-3">USUARIOS 00162181</h4>
              <form action="" method="post" class="needs-validation" novalidate> 
                    <div class="col-md-5 mb-5">
                          <div class="input-group">
                            <div class="input-group-prepend"><span class="input-group-text">DNI</span></div>
                            <input type="text" class="form-control" id="dni" name='dni' placeholder="dni" required>
                          </div>  
                    </div>
                    <div class="col-md-3 mb-3">
                          <div class="input-group">
                            <input type="submit" name='buscar' value="Buscar" class="btn btn-primary btn-lg btn-block" /> 
                          </div>
                    </div>
              </form>
            </div> 
      </div>






<?php
     
$sqlEntregas=$conectar->prepare("SELECT count(*) as totalMenu FROM `menus` WHERE `activo`='1' ORDER BY `menus`.`orden` ASC");
$sqlEntregas->execute();
$registro = $sqlEntregas->fetch(PDO::FETCH_OBJ);
 $totalRegistro=$registro->totalMenu;
 
?>



 <script >
function grupo(cual, estado) {
for (var i = 1; i <=<?php echo $totalRegistro;?>; i ++)
document["forms"]["prueba"][cual + i]["checked"] = estado;
}
</script>


<form name="prueba" method="post">
    <input name="g1T" type="checkbox" onclick="grupo('g1', this.checked)"> Todos <br>
    <?php
    if(isset($_POST['dni'])) {
       // $dni = $_POST['dni'];
        $i=1; 
        $statement = $conectar->prepare("SELECT * FROM `menus` WHERE `activo`='1' ORDER BY `menus`.`orden` ASC");
         $statement->execute();
         $list = $statement->fetchAll(PDO::FETCH_ASSOC);
        // echo "xxx".$list;
  
        if (count($list)){
        echo "<div class='table-responsive'><table class='table table-striped table-sm'><thead><tr><th>N°</th><th>Nombres</th><th>Preferencia</th></tr></thead><tbody>";}

        foreach($list as $col){ echo  "<tr><td>".$i."</td><td>".$col['menu']."</td><td><input name='arrayMenu[]' type='checkbox' value='".$col['codigoMenu']."'></td>
        </tr>  ";  $i++; }

        if (count($list)){ echo "</tbody></table></div>";}
    }
    ?>  
    <input type="text"  name='dni' value="<?php echo $_POST['dni'];?>" >
    <input type="submit" name='Agregar' value="Asignar informacion" class="btn btn-primary btn-lg btn-block" />

<form>




 
<?php
  require 'htmlPie.php'; 
?>