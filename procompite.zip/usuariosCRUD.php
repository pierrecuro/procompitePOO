<?php
require 'htmlCabeza.php';  


if(isset($_POST['Agregar'])) {
		$mensajeError = '';
		$dni = trim($_POST['dni']); 
		$usuario = $_POST['usuario'];
		$clave = $_POST['clave']; 
		if($dni == '') $mensajeError = 'dni';
		if($mensajeError == ''){ 
				try {
				// print_r($_POST); 
				$sql = $conectar->prepare('INSERT INTO usuarios (codigoUsuario, dni,  usuario, clave) VALUES (codigoUsuario,:dni,:usuario,:clave)');
				$sql->execute(array(':dni' => $dni,':usuario' => $usuario,':clave' => $clave));
				echo "<center>fue grabado</center>";
				} 	catch(PDOException $e) {
				echo "<center>error</center>";
				}
		} 
}


if(isset($_GET['eliminar'])) {
		$codigoUsuario= $_GET['eliminar'];
		$sqlDelete = $conectar->prepare("DELETE FROM usuarios WHERE codigoUsuario = ?");
		$sqlDelete->execute([$codigoUsuario]);
		$sqlDelete = null;
}


if(isset($_GET['editar'])) {
		$codigoUsuario= $_GET['editar']; 
		$sqlSelect = $conectar->prepare("SELECT * FROM `usuarios` WHERE `codigoUsuario`= ?");
		$sqlSelect->execute([$codigoUsuario]);
		$unRegistro = $sqlSelect->fetch(PDO::FETCH_LAZY);
		if(!$unRegistro) exit('no hay registros');
		/*similares muestras de registros echo $unRegistro[0];echo $unRegistro->producto; echo $unRegistro['producto'];*/
		$sqlSelect = null;
}

 
if(isset($_POST['Modificar'])) {
		$codigoUsuario= $_POST['codigoUsuario'];
		$dni = trim($_POST['dni']);  
		$usuario = $_POST['usuario'];
		$clave = $_POST['clave'];
		$sqlModificar = $conectar->prepare("UPDATE `usuarios` SET `dni` = '$dni', `usuario` = '$usuario', `clave` = '$clave' WHERE `codigoUsuario` = $codigoUsuario");
		$sqlModificar->execute([$codigoUsuario]);
		$sqlModificar = null;
		header('Location: usuariosCRUD.php?action=2');
}

 
 /*
$tablaMargesiTipo = $conectar->prepare("SELECT * FROM `margesi` WHERE `tipo`='TIPO'");
$tablaMargesiTipo->setFetchMode(PDO::FETCH_ASSOC);
$tablaMargesiTipo->execute(); 

$tablaMargesiActivo = $conectar->prepare("SELECT * FROM `margesi` WHERE `tipo`='ACTIVO' ORDER BY `usuario` DESC");
$tablaMargesiActivo->setFetchMode(PDO::FETCH_ASSOC);
$tablaMargesiActivo->execute(); */

 
?> 
<div class="container">
  <h4 class="mb-3">usuarios</h4>

<form action="" method="post"  > 
<div class="row">
                 
<script> function PopupCenter(pageURL, title,w,h) {
var left = (screen.width/2)-(w/2);
var top = (screen.height/2)-(h/2);
var targetWin = window.open (pageURL, title, 'toolbar=no, location=no, directories=no, status=no, menubar=no,scrollbars=no, resizable=no,copyhistory=no,width='+w+',height='+h+',top=2,left='+left);
} </script>


                        

<div class="mb-3"> 
  <div class="input-group">
    <a  href='#' onclick="PopupCenter('usuariosCRUDvalidez.php', 'Informations',800,500);"><img src='imagen/lupa.png'></a>

    <div class="input-group-prepend">
      <span class="input-group-text">DNI</span>
    </div>
    <input type="text" class="form-control" id="username" name='dni' placeholder="dni" required value="<?php if(isset($_GET['editar'])) {  echo $unRegistro->dni; }?>">
    <div class="invalid-feedback" style="width: 100%;">
      DNI
    </div>



  </div>
</div>        

<div class="col-md-3 mb-3"> 
  <div class="input-group">
    <div class="input-group-prepend">
      <span class="input-group-text"> Usuario</span>
    </div>
    <input type="text" class="form-control" id="username" name='usuario' placeholder="usuario" required value="<?php if(isset($_GET['editar'])) {  echo $unRegistro->usuario; }?>">
    <div class="invalid-feedback" style="width: 100%;">
      DNI
    </div>
  </div>
</div>

<div class="col-md-3 mb-3"> 
  <div class="input-group">
    <div class="input-group-prepend">
      <span class="input-group-text"> Clave</span>
    </div>
    <input type="text" class="form-control" id="username" name='clave' placeholder="Clave" required value="<?php if(isset($_GET['editar'])) {  echo $unRegistro->clave; }?>">
    <div class="invalid-feedback" style="width: 100%;">
      DNI
    </div>
  </div>
</div>
  
 



<div class="col-md-3 mb-3">






<?php if(isset($_GET['editar'])) {?>
<input type="submit" name='Modificar' value="modicar" class="btn btn-primary btn-lg btn-block" /> 
<input type="hidden"  name="codigoUsuario"  value="<?php if(isset($_GET['editar'])) {  echo $unRegistro->codigoUsuario; }?>" > 
<?php  } else {  ?>
<input type="submit" name='Agregar' value="Agregar" class="btn btn-primary btn-lg btn-block" />
<?php  }?>
</div>
<div class="col-md-2 mb-2">
<a href="usuariosCRUD.php" class="btn btn-primary btn-lg btn-block" style="background: #fff !important;color: #000 !important;" />Nuevo</a>
</div>

  </div> 
</form>

<!---INICIO LISTADO---->
<h2>Lista de Usuarios</h2>
          <div class="table-responsive">
            <table class="table table-striped table-sm">
              <thead>
                <tr  align="">
                  <th>N°</th>
                  <th>codigoUsuario</th>
                  <th>dni</th> 
                  <th>usuario</th> 
                  <th>clave</th>  
                  <th> </th>  
                </tr>
              </thead>
              <tbody>                 
					<?php
					$i=1;
					$sqlPDO = $conectar->prepare("SELECT * FROM `usuarios`");
					$sqlPDO->execute(array(':codigoUsuario' => 0));
					$lista = $sqlPDO->fetchAll(PDO::FETCH_ASSOC);
					foreach($lista as $obj){  
					echo  "<tr><td>".$i."</td><td>".$obj['codigoUsuario']."</td><td>".$obj['dni']."</td> <td>".$obj['usuario']."</td> <td>".$obj['clave']."</td>      <td> <a href=?editar=".$obj['codigoUsuario'].">Editar</a></td><td> <a href=?eliminar=".$obj['codigoUsuario'].">eliminar</a></td>  </tr>";  $i++;
					}?>
              </tbody>
            </table>
          </div> 
<!---FIN LISTADO---->


</div>        
 
<?php
  require 'htmlPie.php'; 
?>