<?php
require 'config.php';
if(empty($_SESSION['nombreCompleto']))
header('Location: index.php');
$codigoUsuarioSession=$_SESSION['codigoUsuario'];

//print_r($_POST);

?>
<!doctype html>
<html lang="en">
  <head>
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
            <meta name="description" content="">
            <meta name="author" content="">
            <link rel="icon" href="imagenes/favicon.ico">
            <title>>Buscar Usuarios</title>
            <!-- Bootstrap core CSS -->
            <link href="css/bootstrap.min.css" rel="stylesheet">
            <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
            <script>window.jQuery || document.write('<script src="js/vendor/jquery-slim.min.js"><\/script>')</script>
            <script src="js/vendor/popper.min.js"></script>
            <script src="js/bootstrap.min.js"></script>
            <!-- Custom styles for this template -->
            <link rel="stylesheet" href="css/menus.css">
            <script src="css/menus.js"></script>
            <!-- autocompletar -->

            <link href='css/autocompletar.css' type='text/css' rel='stylesheet' >
            <script src="js/jquery-3.2.1.min.js" type="text/javascript"></script>
            <script src="js/autocompletar.js" type="text/javascript"></script>
         



  </head>
  <body>

 


<?php 
 

if(isset($_POST['Buscar'])) {

if(isset($_POST['buscarDNI']) and $_POST['buscarDNI']!='' ) {
      $dni = trim($_POST['buscarDNI']);
 

    $sqlDNI=$conectar->prepare("SELECT *  FROM  personas   WHERE dni='$dni'");
    $sqlDNI->execute();
    $registro = $sqlDNI->fetch(PDO::FETCH_OBJ); 
 

    if(isset($registro->dni)) { 
        //$codigoUnificado=$registro->codigoUnificado;
        $dni=$registro->dni;
        $nombreCompleto=$registro->nombres." ".$registro->aPaterno." ".$registro->aMaterno;
        echo "<center><h1 style='color:blue;'> Nombre Completo: <br>".$nombreCompleto." <br> DNI :".$dni." <br>Fecha Nacimiento:".$registro->fechaNacimiento."<br>   </h1></center>";  
 

    } else { echo "<center><h1 style='color:red;'>no existe en la base de datos este DNI :".$_POST['buscarDNI']."</h1></center>"; 
     $totalEntregas='0';
  }
 
 }
 }

 
?> 
<div class="container">
  <h4 class="mb-3">Buscar Usuario</h4>

<form action="" method="post"  > 
<div class="row">
 
 
<div class="mb-3"> 
  <div class="input-group">
    <div class="input-group-prepend">
      <span class="input-group-text">DNI</span>
    </div>
    <input type="text" class="form-control" id="username" name='buscarDNI' placeholder="dni" required value="">
    <div class="invalid-feedback" style="width: 100%;">
      DNI
    </div> 
  </div>
</div>        
 
   

<div class="col-md-3 mb-3">
<input type="submit" name='Buscar' value="Buscar" class="btn btn-primary btn-lg btn-block" />
</div>
 

  </div> 
</form>

 
 
 
    </div>

  

 
  </body>
</html>
